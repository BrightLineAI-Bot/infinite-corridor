## Rendered preview observations

Verified exact isolated preview `https://brightlineai-bot.github.io/infinite-corridor/previews/r455-04c11a0d3b73/`, via PR210 preview receipt and its release-identity.json: candidateCommit `04c11a0d3b73eeb9c767e9548cd3724c92a8dba9`, candidateTree `54fdea1a0e8d7395c616e60415c9e263b27ee8f3`. Cloud Chrome viewport 1180×757. Preview header independently displays exact release. This is Proving Ground scratch UI, not production save or normal journey UI.

### MAJOR in preview only — Diagnostics opens an invisible modal and disables the play surface

- Reproduce: open exact preview, click top **Diagnostics**. The button handler executes; `#pgDiagnostics` has `open:true`, `hidden:true`, computed `display:none`, rectangle 0×0. Menu stays visible but subsequent laboratory/Hide clicks do nothing; semantic keyboard attempts timeout. Reloading preview clears modal and laboratory selection immediately works.
- Expected: visible, readable diagnostics dialog with accessible Close control; background restored on dismissal.
- Actual: invisible modal makes background inert. No crash or production data loss demonstrated. One clean browser invocation of Diagnostics reproduced; source supports deterministic root cause, not a population rate. No claim Escape is broken for human keyboard: the automation's semantic Escape action could not focus an inert element.
- Source: `src/proving-ground.ts:6` hides every `dialog`; `src/proving-ground-mobile.ts:13` calls `dialog.showModal()` without clearing hidden. In addition, `styles.css:668` explicitly hides every Proving Ground dialog with `display:none!important`; merely clearing hidden is insufficient. `styles.css:677` overrides this for open Glimpses, but `:678` has no analogous Diagnostics display override. Suggested fix area: preview dialog visibility/initialization including the CSS blanket rule; add rendered open/close regression.
- Evidence screenshot `ic-preview-hidden-diagnostics.jpg` shows unchanged launcher (the absence of visible dialog); decisive evidence is DOM properties above, not screenshot alone.
- Counter-check: Glimpses has hidden=true/open=true but computed display:block, nonzero392×551.84 rectangle due its styling, so **not** the same confirmed defect. Do not generalize every modal broken.

### Actual rendered checks and player-feel notes

After reload, selected Monster & Elite Combat Arena → Void Walker → Start test → Pause; developer recipe showed `CINDER-VERGE-47`, variant0, standard test tile, one live voidWalker, playerHP60. Menu Hide/Dev menu toggles worked. Used developer teleport “Near the combatants”, Resume and Attack; observed actual renderer's Walker/orb effects, player melee arc, tile/water/collision scene and on-screen action diamond. Saved paused and live screenshots. These are short rendered scratch observations, not ordinary-loadout encounter statistics or manual mobile play.

At desktop size, the player silhouette and gold melee arc are distinct against muted tiles; purple floating effects differ from terrain, and action controls remain visible. The fixed preview banner occupies substantial upper-center space, and the full developer panel obscures the left portion until collapsed. These are preview UI costs, not proof of production camera problems. The near-combatants fixture places action by the map's northern boundary, so camera shows dark out-of-map space; it is not proof all natural worldboss encounters frame poorly. No pixel-timed warning/reaction evaluation or hitbox alignment measurement was performed.

Browser console errors observed were extension metadata errors with chrome-extension origins, not game-source exceptions; do not report them as game defects. The in-page diagnostic DOM recorded Recent errors:none, but this is not exhaustive exception capture. No production journeys, real saves, caches or account state were cleared/imported. Scratch fixture and menu-collapse state changed as expected from UI tests.

### UI limits and environment boundary

390×844 and844×390 viewport tests, touch-device latency, Pack/Journal/Tome/kitchen/smith/Atlas normal-game dialogs, full boss rendering matrix and accessibility contrast remain untested. Supported cloud browser exposed no viewport-resize capability. Local isolated dist server could not be reached across command network namespaces; one shared-loopback escalation failed before execution (`bwrap` read-only protected sessions path), was not retried and no protected path was accessed. Exact remote preview provided an independent approved route, not a workaround for denied file access. Do not claim local server tests succeeded.
