import {Game,footprintOpen} from '../repo/src/game.ts';
import {freshSave} from '../repo/src/types.ts';
import {canStep} from '../repo/src/landscape.ts';
const save=freshSave(); save.seed='CLOUD-WORLD-24'; const g=new Game(save,0);g.rx=48;g.ry=10;g.loadArea('overworld',false);const m=g.map,o=m.objects.find(o=>o.id==='landmark-48,10');
// Supplemental sampled static reachability, not a natural journey or tool-use proof.
// Permit eight directions, fractional coordinates and the production +1 jump step.
for (const scale of [2,4,10]) {
 const width=32*scale, seen=new Uint8Array(width*width), q=[[16*scale,16*scale]], dirs=[[-1,0],[1,0],[0,-1],[0,1],[-1,-1],[-1,1],[1,-1],[1,1]]; let best={distance:Infinity};
 for(let i=0;i<q.length;i++){
  const[ix,iy]=q[i],k=iy*width+ix,x=ix/scale,y=iy/scale;
  if(ix<0||iy<0||ix>=width||iy>=width||seen[k]||!footprintOpen(m,32,x,y))continue;seen[k]=1;
  const distance=Math.hypot(x-o.x,y-o.y);if(distance<best.distance)best={x,y,distance};
  for(const[dx,dy]of dirs){const nx=(ix+dx)/scale,ny=(iy+dy)/scale;if(canStep({isPlayer:true,jumping:true},m,32,x,y,nx,ny))q.push([ix+dx,iy+dy]);}
 }
 console.log(JSON.stringify({seed:save.seed,object:o.id,gridStep:1/scale,directions:8,reachable:seen.reduce((a,b)=>a+b,0),best,interactionReachable:best.distance<1.5}));
}
