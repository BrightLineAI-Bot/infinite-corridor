## Cloud reachability audit — release 455

Read-only production-source execution at `/tmp/ic-audit-cloud/repo`, pinned `04c11a0d3b73eeb9c767e9548cd3724c92a8dba9`. All harnesses/output are outside the repository in `/tmp/ic-audit-cloud/reachability`. No production code, config, save files, branches, or external services were changed. In-memory test saves/maps were created and discarded.

### Reproduced finding: runtime cistern water can sever the guardian route

**Impact:** Mislaid Threshold progression can be obstructed for an unequipped character. The normal entrance refuses to release the player until the distant guardian falls; Stuck and death return to the same entrance. This is **not a claim that every character is permanently softlocked**: a held Crossing Sigil escapes, and traversal magic, swimming equipment or digging resources may provide alternatives. Ordinary cisterns can also lose their walking route, but retain an ordinary exit.

**Cause:** `src/game.ts:2062–2067` changes `(11,4), (12,4), (11,5), (12,5)` into blocked `dungeonWater` whenever the recipe is `cistern`, without restricting the override to its original layout or rechecking connectivity. It runs after `generatePinnedDungeon` (`2022–2023`). It can break maps that pass generator-level traversal diagnostics. The generic terrain-hazard protection at `src/arenas.ts:31–38` does not undo water already present.

**Natural-world reproduction (not an injected device):**
1. `freshSave()`, explicitly set `seed='CLOUD-WORLD-105'`; `new Game(save,0)`.
2. Set Game section to `(48,-3)` and `loadArea('overworld',false)`.
3. The actual generated object `shelter-surprise-48--3` is a Mislaid Threshold at `(22,8)`.
4. Place the test player beside it and call `interact('enter',object.id)` (success).
5. Dungeon ID is `displacement:48:-3:shelter-surprise-48--3`, entry `(20,4)`. Its reachable component has 109 tiles; guardian is at `(4,16)` outside it.
6. `interact('exit','dungeon-exit')` refuses while guardian lives. `unstick` returns `(20,4)`. `returnHome` refuses dungeon travel. `useCrossingSigil` fails with no sigils. Fresh resources are zero.

Executable: `node /tmp/ic-audit-cloud/reachability/natural-repro.mjs`; evidence: `natural-repro.log`, `natural-map.json`.

**Stronger isolated combat/recovery check:** seed `THRESH451-82`, level 30, section `(5,-3)`, device fixture `seam-82` copied from `tests/threshold-door-451.test.ts`. Result ID `displacement:5:-3:seam-82`; entry `(4,4)`, guardian hollowMarshal `(35,36)`. Only 29 floor cells are connected. Nearest entry-component position to guardian is `(10,4)`, distance 40.6079 tiles, with no line of sight. A 3,600-update / 120-second headless simulation with this guardian alone leaves it at `(35,36)`; it never enters the entry component. A normal Jump while moving into the water kills and returns the player to the same dungeon entrance. Stuck likewise returns the entrance. This checks ordinary guardian movement, not all possible ranged/magic/equipment loadouts or forced aggro strategies.

Executable: `repro.mjs 82`, `guardian-check.mjs`; evidence: `threshold-82-repro.txt`, `threshold-82-map.json`, `guardian-check.log`.

**Measured incidence and causal isolation:**
- 400 actual Game displacement fixtures, `THRESH451-0` through `THRESH451-399`: 18 disconnected-guardian cases. Every one was independently regenerated and became connected when *only* the four cistern override cells were restored in memory from its generated pre-runtime map. Thus all 18 are confirmed route disconnects, not merely untriaged flood-fill warnings. This does not mean all 18 are absolute softlocks.
- Indexes: `32,38,45,52,65,82,112,125,142,145,162,205,238,252,288,305,382,392`; section `(5,-3)`, object `seam-<index>` for each.
- 47 actual naturally generated devices found in the surface sweep: one disconnected case (above), independently verified using the real interaction.
- 1,000 Game-loaded ordinary maps (200 per v2/v3/v4/v5/current pin): four current-generation route candidates; none in the other four cohorts. Current seed indexes `32,72,122,171` under `CLOUD-RUNTIME-<i>`; exact IDs/coords in `runtime-summary.json`. These four have not each received combat/escape simulations and remain route candidates, not four separately asserted softlocks.

**Relevant recovery mechanics:** exit lock `game.ts:2971`; Stuck `2517–2535`; dungeon Wayglass/home refusal `2445–2453`; resource-gated Crossing Sigil escape `3402–3417`; ordinary jump does not suppress terrain death `4650–4656`. Both warp daises must be independently attuned before teleportation (`2774–2785`); the confirmed isolated #82 has no dais.

### Actual coverage

| Suite | Cases | Result / qualification |
|---|---:|---|
| Direct ordinary generation, versions 2/3/4/5/current | 1,000 | No arrival/exit/guardian/dais route candidates |
| Direct deep-v1 | 200 | No candidates after final gate tiles opened in test state |
| Direct deep-v2, all five archetypes and all their levels | 1,600 | No exit/transition/guardian candidates after final gates opened; not a simulated full objective playthrough |
| Actual Game ordinary loads | 1,000 | Four current-generation guardian-route candidates |
| Actual Game synthetic Threshold starts | 400 | 18 causally verified route disconnects |
| Actual Game natural Threshold starts | 47 | One route disconnect, confirmed through actual enter interaction |
| Special direct generation: grotto, original dive, arena, hunt-instance, elite portal, annex, Far Array run, Listener hall, dream dungeon | 1,800 | 200 each; no route candidates for tested exits/daises/bosses/sea spawns |
| Surface and Far Sleep generated sections | 2,400 | 200 seeds × 12 coordinates; 478 service objects checked; one walking-access caveat below |

Total: **8,447 map/section cases**, plus focused independent reproduction and causal checks. Distinct suite seed namespaces comprise 1,200 seeds (400 Threshold and 200 each direct-map/runtime/world/special); this is not 8,447 unique seeds. The natural-device cases reuse the world seed cohort.

### Surface access caveat (not a progression blocker claim)

`CLOUD-WORLD-24`, section `(48,10)`, naturally generated `landmark-48,10` Lattice Wayglass at `(13,12)` is outside the plaza's normal footprint-connected component, also after actual `Game.loadArea`. Nearest reachable integer position is `(15,14)`, 2.8284 tiles away (interaction limit is <1.5). Nearby blocked cells are ordinary terrain, not an unopened door; no door object supplies a missing transition. Overworld digging may provide access, so this is a walking-access finding, not evidence it is impossible with tools. `wayglass.mjs`, `wayglass.log`, `wayglass-map.json` reproduce it.

### Method and limitations

Floods use the production `footprintOpen` and player `canStep` with jump-enabled +1 elevation, cardinal integer positions and <1.5 interaction proximity. The main/special/runtime sweeps do not invent warp edges: daises must themselves be walk-accessible before their two-ended attunement can help. The original 400 Threshold sweep permissively included paired-dais edges; its 18 failures still fail even under that allowance, and their individual causal checks confirm real separation. Hazards and hostile combat are not exhaustively simulated. Direct generators do not substitute for Game runtime—this distinction exposed the main finding.

Not covered exhaustively: linked-mouth round trips, cross-level objectives/shortcut unlocking, every exit edge of every overworld section, old save migrations or snapshots, remembered/custom town Wayglass injection, boats/swimming/breath budgets, arbitrary magic/ranged equipment, continuous sub-tile routes, visual rendering/mobile/offline performance, or an entire naturally travelled route from initial refuge to the reproduced far-away device. No launch/publish/fix authorization inferred.

### Artifacts / repeat commands

- `sweep.mjs`: modes `threshold`, `maps`, `runtime`, `natural`, `special`; summaries `<mode>-summary.json`, logs `<mode>.log`.
- `world.mjs`, `world-summary.json`, `world.log`: 2,400 sections and discovered natural devices.
- `classify.mjs`, `threshold-causal.json`, `threshold-causal.log`: independent 18-case four-cell causal intervention.
- `natural-repro.mjs/.log`, `natural-map.json`: natural device actual enter interaction.
- `repro.mjs`, `threshold-82-repro.txt`, `threshold-82-map.json`: isolated fixture, water-jump death, Stuck and Sigil.
- `guardian-check.mjs/.log`: 120 simulated seconds, distance and line of sight, actual home refusal.
- `wayglass.mjs/.log`, `wayglass-map.json`: service walking-access caveat.

No action was blocked or denied. The original historical 4/120 seed scheme was not available; these are independent cloud reproductions, not a claimed exact replay of those earlier four seeds.
