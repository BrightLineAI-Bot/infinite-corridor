import {Game} from '../repo/src/game.ts';
import {freshSave} from '../repo/src/types.ts';
import {rng} from '../repo/src/random.ts';
import {writeFileSync} from 'node:fs';
const rows=[];
for(let n=0;n<10;n++){
 const s=freshSave();s.seed=`AUDIT-ENDURANCE-${n}`;const g=new Game(s,0),r=rng(s.seed),row={seed:s.seed,frames:0,deaths:0,peaks:{},samples:[],errors:[]};let death=null;const start=performance.now();
 for(let f=1;f<=18000;f++){
  const a=new Set(['attack','dodge','jump','interact','potion','tool','spell'].filter(()=>r()<.06));
  g.update(1/30,{state:{x:Math.floor(r()*3)-1,y:Math.floor(r()*3)-1},consume:k=>a.delete(k),held:()=>false,reset(){}},f*1000/30);
  if(s.lastDeath!==death){death=s.lastDeath;row.deaths++;}
  for(const k of ['enemies','effects','packEffects','projectiles'])row.peaks[k]=Math.max(row.peaks[k]||0,g[k]?.length||0);
  for(const [k,v] of Object.entries({x:g.player.x,y:g.player.y,hp:g.player.hp,stamina:g.player.stamina,currency:s.currency}))if(!Number.isFinite(v))row.errors.push({f,k,v:String(v)});
  if(f%1800===0)row.samples.push({f,enemies:g.enemies.length,effects:g.effects.length,packEffects:g.packEffects.length,projectiles:g.projectiles.length,area:g.area,rx:g.rx,ry:g.ry,saveBytes:JSON.stringify(g.exportSnapshot(f*1000/30)).length});
  row.frames=f;if(row.errors.length)break;
 }
 row.wallMs=performance.now()-start;rows.push(row);writeFileSync('/tmp/ic-audit-cloud/endurance/results.json',JSON.stringify(rows,null,2));console.log(JSON.stringify(row));
}
