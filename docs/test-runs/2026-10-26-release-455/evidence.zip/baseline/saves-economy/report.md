# Save / progression / economy custom audit

Read-only repository: `/tmp/ic-audit-cloud/repo`, pinned `04c11a0d3b73eeb9c767e9548cd3724c92a8dba9` (r455). Only harnesses/logs/results/report in this artifact directory were written. No source changes or test-suite duplication.

## Findings

### P2 — Malformed meal accepted as healthy crashes Game construction

Reproduction (deterministic JSON mutation, **not** evidence a normal player produces this save): take `freshSave()` and replace `meal` with `{"a":"constructor","b":"ironroot","remaining":10}`. `validateJourney(raw).health` is `healthy`; `new Game(validateJourney(raw).save, 0)` throws `TypeError: Cannot convert undefined or null to object`. `a:"__proto__"` reproduces independently.

`src/meals.ts:31` and `:44` test truthiness of `INGREDIENTS[key]`, including inherited Object properties, rather than pantry membership. `:46` then calls `Object.entries(undefined)` on the inherited entry's absent bonus. Stack reaches `characterStats` (`game.ts:328`), `syncCharacterStats`, `settleProgression`, and `new Game` (`game.ts:1521`). Validation (`persistence.ts:16`) does not instantiate gameplay; load selection (`persistence.ts:30`) can therefore select this nominally healthy candidate. This is a malformed-import/load robustness defect, not demonstrated spontaneous save corruption or a security escape.

### P2 — Nonfinite numerical save inputs survive healthy validation and poison runtime/economy

Independently mutate fresh save JSON with `currency:"1e309"`, `stats.Vigor:"1e309"`, or `playSeconds:"1e309"`. Each passes `validateJourney` as healthy. First: `eatMeal(save,"ironroot","ironroot")` succeeds and produces numeric `Infinity` currency. Second: `new Game` has `Infinity` HP/maxHP. Third: migration returns infinite playSeconds. Numeric JSON value `1e308` is also accepted, with no reasonable stat ceiling; arbitrary negative currency also remains unchanged.

Source: raw scalar/stat merges in `types.ts:16`; only level gets finite validation in `persistence.ts:16`; playSeconds uses `Math.max(0,Number(...)||0)` at `types.ts:42`; game stat coercion/math `game.ts:311-330`; meal charge `meals.ts:62-65`. JSON serialization converts Infinity to null, so downstream round trips do not preserve these invalid values. These are injected robustness cases, **not** observed gameplay-generated values.

### P3 / contract gap — migrateSave is not total over malformed containers

275 one-field JSON mutation cases (25 paths × 11 values) yielded 27 exceptions. Examples: `inventory:{}` → map is not a function (`types.ts:46`); `narrative.journal:{}` → not iterable (`types.ts:16`); `session.areas:{"dungeon:x":null}` → cannot read enemies (`types.ts:36`); null history → cannot read layoutVersion (`types.ts:44`). All 27 are caught/classified damaged by `validateJourney`, so distinguish failure of the requested nonthrowing-normalization contract from an uncaught normal production loader failure. Complete exact mutations/errors are `migration.json`.

## Passed independent sweeps

- 100 deterministic seeds `AUDIT-PLAY-0`…`99`, 180 frames at 1/30 each = 18,000 updates. Random movement/attack/dodge/jump/interact/potion; pause/resume at frame65 and forced zero-HP death at frame120. Eight JSON serialization+migration+Game reconstruction checks per seed = 800 resumes, comparing region/position and HP/stamina/attack cooldown/motion/melee motion/dodge cooldown/invulnerability/dodge motion/jump/guard to 1e-7 tolerance. Finite numeric characterStats/player position/resources checked each frame. Zero failures.
- 100 economy seeds `AUDIT-ECON-0`…`99`: 60 paired-meal attempts each (6,000 attempts), exact mark charges, insufficient funds, JSON persistence, 901-second expiry; one-time socket/masterwork purchase and 20 repeated refusals after reload; salvage removal and 20 replay refusals; lore heard-line persistence. Zero failures.
- Threshold seeds `AUDIT-THRESH-0`…`59`: 54 guarded crossings exercised, 6 skipped because no guardian generated. Mark enemies dead, call actual guardian defeat handler, export/JSON/migrate/reconstruct, verify threshold-door and use it to exit/displacement cleared. Zero failures. This is synthetic defeat setup, not simulated full boss combat.
- 80 shop seeds: unique equipment cannot be purchased twice across reload; quantity requests -1/0/1/10/999/1e308 preserve charges and 99 supply cap.
- 400 hunt completion→JSON migration→repeat-completion checks, no duplicate reward.
- 80 one-time shelter gift replay checks across reload, no duplicate reward.
- 80 valid-cook meal purchases and far-away refusal checks, refusal preserves marks.
- 480 exhaustive Aperture-band × Listener-count(0…5) × Walker-slain(0/1) combinations against dive/sub/underwater/mech/drone gate rules.
- Five partial/empty/large inputs, including one 1,000,000-byte unknown field preserved by migration.

## Boundaries

The random-action runs begin in the refuge and are only six seconds of simulated unpaused movement per seed; they are not deep-world combat endurance, exhaustive area transitions, all statuses/spells, or true browser storage suspension. No IndexedDB/localStorage crash/quota recovery or real user save sampled. No natural source for malformed cases established. General inventory/reward coverage is limited to listed purchases, services, hunts, gifts, lore, and Threshold progression. Reforge cost behavior not independently swept (full repository suite handled by parent). No devices, touch rendering, or performance claims. The 1MB case is a preservation check, not a resource exhaustion stress test.

## Artifacts / rerun

- `audit.mjs` → `node /tmp/ic-audit-cloud/saves-economy/audit.mjs`; results.json, migration.json, run.log.
- `extra.mjs` → `node /tmp/ic-audit-cloud/saves-economy/extra.mjs`; extra.json, extra.log.
- `extra.json` spells nonfinite outcomes in its `nonfinite` arrays (JSON numeric null otherwise denotes serialized Infinity).

## Added direct isolation and loader-fallback checks

Command: `node /tmp/ic-audit-cloud/saves-economy/isolation.mjs > /tmp/ic-audit-cloud/saves-economy/isolation.log 2>&1`. Full outcomes: `isolation.json`.

- **Tested:** 82 scenarios across six scratch lab families (hunts, inventory, magic, recovery, scenes, records), seed `ISOLATION-455`: construct fixture, mutate its currency, export snapshot. Separate production sentinel stays byte-identical, and instrumented localStorage / IndexedDB receive no calls. Fixture factory `proving-ground-labs.ts:91,300–317`; memory-only roundtrip `:21`. This proves tested fixture paths do not reach production storage; it does not exercise browser UI reset or every lab.
- **Tested:** Execute the actual production and PG service-worker source in separate Node VM contexts, invoke activate with five fake cache names. Production deletes only `infinite-corridor-v454`; PG deletes only `ic-proving-ground-pg1-r454`; both retain current versions, the other app's cache, and unrelated caches. Code `sw.js:114–118`, `proving-ground/sw.js:3`. **Not tested:** real browser worker registration/scope, request handling/cross-cache fetch behavior, offline navigation, browser eviction, mobile shell reset.
- **Tested:** Invoke real `loadSave` (`persistence.ts:30`) against in-memory asynchronous IndexedDB and localStorage adapters: newer IDB `inventory:{}` save is rejected and older healthy mirror selected; both empty returns valid fresh game. Critically, newer IDB meal `{a:'constructor',b:'ironroot',remaining:10}` wins over an older genuinely healthy mirror and then `new Game` throws. This directly confirms the fallback-selection consequence of P2 #1, with controlled malformed bytes. **Not tested:** actual browser IndexedDB/localStorage operations or storage failure timing.

Severity clarification: the two P2 findings are **major for the explicitly requested corrupted-save/import robustness contract**, qualified as malformed-input-only. They do not establish naturally occurring gameplay corruption, a normal-input progression blocker, or a security exploit. The 27 caught migration exceptions are **minor** relative to production fallback because damaged candidates are rejected. No UI/device/browser claims. Ghost-resource retention/growth was not instrumented; finite resource accounting and one-time replay checks are not a heap-leak test.
