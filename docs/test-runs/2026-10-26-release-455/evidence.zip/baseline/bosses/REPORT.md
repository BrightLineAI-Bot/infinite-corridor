# World-boss and Far Array headless audit — release 455

Pinned source: `04c11a0d3b73eeb9c767e9548cd3724c92a8dba9`. Read-only repository; all harnesses/results are under `/tmp/ic-audit-cloud/bosses`. No fixes, commits, pushes, workflows, secrets or environment-variable reads. Final git status was clean.

## Evidence and limits

This is **scripted headless production `Game.update`, not human play**. The matrix contains 216 world-beast/Questing encounters and 72 Far Array encounters. Seeds: `BOSS-AUDIT-101`, `BOSS-AUDIT-202`, `BOSS-AUDIT-303`. Each kind uses levels 8/20; two builds; two input policies. Simulation step 50 ms, stopping at first death, boss kill, retreat, nonfinite state, or 180 seconds. No health/damage/invulnerability cheats. Actual damage, attack selection, enemy AI, stamina, dodge, potions and targeting run in the production game.

**Synthetic setup, not naturally earned:** XP is granted through `awardExperience` to reach each level, then all earned stat points are allocated round-robin Might/Vigor/Finesse/Resolve/Focus through `Game.allocate`. Starter gear is unchanged; rank3 gear uses `upgradeEquipment` three times per slot against fixture-granted spheres, which are removed afterward. This yields primary/tool/armor power 6/3/1 versus 9/6/4. No glyphs, echoes, constellation choices, advanced spell unlocks or rare loot: these are conservative valid builds, not representative optimized endgame builds. Three default draughts; adaptive policy can use them. World beasts get their minimum natural Aperture-tier threshold (tiers3–8), but spawn is directly enrolled, **not** a natural encounter-frequency measurement. Far Array uses Aperture90, Gate2, ten synthetic answered relays and a synthetic prior Listener clear; open/walled choices match restore/sever. Far Array `tuneArrayBoss` is applied after creation, as `Game.loadArea` does at `src/game.ts:2137`.

World arena is a synthetic unobstructed 32×32 floor bounded by walls, at section `(7,2)`, player `(14,16)`, boss `(18,16)`. Boss IDs: `audit:<seed>:<kind>`. Array uses the native `generateListenerArena` map, ID `far-array:<seed>:arena1`; boss IDs end `:listener` or `:guardian`; player/boss repositioned to the same coordinates for a controlled start. Native hall geometry/pylons retained. No ocean loadout in these balance measurements.

Novice policy approaches within1.2 tiles, presses melee every0.5s, dodges every4s, and uses neither tools nor potions. Adaptive policy reads current attack-state (a nonvisual oracle), reacts after350ms, circles/backs away, requests dodge at least1.3s apart, melee every0.3s, tool every0.8s, spell every4s, potion below50% HP. Stamina/cooldown rules still apply. It does not learn counters, jump shockwaves, prioritize summons, avoid every individual effect, or infer telegraph pixels. Therefore “adaptive” is a policy name, **not** proof of skilled play; it sometimes performs worse than simple melee. Movement near arena edges steers inward, never teleports. Not a mobile-input or rendering/readability audit.

Raw JSON records contain every setup, derived player stat, gear, starting boss HP/damage, hit times and capped HP losses, attack selections, remaining HP, targetability duration and peak actors/effects/projectiles. Fatal hits are HP-clipped, not raw overkill. Array death frames can include recovered-area actors in generic actor maxima; mirror/worm maxima remain separately measured. Do not treat repeated seeds as independent statistical samples or these outcomes as human win probabilities.

## Matrix outcomes

Time is time to **terminal outcome**, not TTK unless the boss actually died. Each row contains12 cases (3 seeds×2levels×2builds).

| Boss | Policy | Boss kills/12 | Time min/median/max (s) | Median boss HP remaining | Peak live actors / pack effects / shots |
|---|---|---:|---|---:|---|
| morphingBlob | novice | 0 | 5.85/7.90/11.80 | 89.4% | 5 / 22 / 0 |
| morphingBlob | adaptive | 0 | 22.65/31.85/55.15 | 57.2% | 5 / 25 / 1 |
| tremorWorm | novice | 0 | 6.20/8.57/17.55 | 74.4% | 3 / 26 / 0 |
| tremorWorm | adaptive | 0 | 25.00/35.65/46.50 | 54.2% | 5 / 30 / 1 |
| mountainTurtle | novice | 0 | 9.95/12.45/26.60 | 83.9% | 1 / 15 / 0 |
| mountainTurtle | adaptive | 0 | 27.90/32.65/37.70 | 71.4% | 1 / 17 / 1 |
| nanobotKnight | novice | 0 | 4.80/6.85/11.90 | 100.0% | 1 / 9 / 0 |
| nanobotKnight | adaptive | 0 | 11.25/20.95/40.45 | 83.8% | 1 / 8 / 1 |
| lightningGiant | novice | 0 | 6.95/14.82/18.45 | 44.9% | 1 / 6 / 0 |
| lightningGiant | adaptive | 0 | 23.90/37.08/55.20 | 74.3% | 1 / 5 / 1 |
| psychicCrystal | novice | 6 | 4.80/16.23/24.50 | 17.8% | 1 / 16 / 0 |
| psychicCrystal | adaptive | 0 | 30.55/40.83/49.55 | 52.9% | 1 / 28 / 1 |
| voidWalker | novice | 0 | 4.60/5.62/10.25 | 81.2% | 1 / 33 / 0 |
| voidWalker | adaptive | 0 | 6.15/16.50/27.50 | 79.0% | 1 / 36 / 1 |
| astralWorm | novice | 0 | 3.80/6.65/10.45 | 81.5% | 1 / 0 / 0 |
| astralWorm | adaptive | 0 | 10.90/28.80/39.60 | 64.5% | 5 / 0 / 1 |
| questingBeast | novice | 0 | 3.50/4.12/6.65 | 97.3% | 1 / 18 / 0 |
| questingBeast | adaptive | 0 | 9.40/14.60/20.30 | 92.1% | 1 / 30 / 1 |
| listener-open | novice | 0 | 20.65/22.75/24.80 | 52.5% | 11 / 11 / 3 |
| listener-open | adaptive | 0 | 43.80/54.08/68.10 | 28.3% | 14 / 10 / 5 |
| listener-walled | novice | 0 | 23.75/33.45/34.55 | 58.0% | 7 / 2 / 41 |
| listener-walled | adaptive | 1 | 81.85/105.22/134.50 | 13.9% | 9 / 4 / 46 |
| guardian | novice | 12 | 27.50/29.75/31.50 | 0.0% | 2 / 1 / 0 |
| guardian | adaptive | 12 | 28.80/47.15/51.00 | 0.0% | 2 / 1 / 1 |

Outcome totals: world {'player-death': 210, 'boss-kill': 6}; Array {'player-death': 47, 'boss-kill': 25}.

## Reproducible player-feel signals (not correctness defects)

**High-priority balance review, not a blocker:** the Questing Beast and Walker leave short novice learning windows on these lean builds. Owner direction deliberately makes Questing dominate other beasts; `src/world-beasts.ts:397–413` specifies the level8 floor and60 damage reference, and `src/questing-beast.ts:47–48` enforces1.15× dominance. This is not automatically a bug. The four-try/wound-carryover contract also means a first-life loss is not a failed hunt. This matrix stops at first death and cannot estimate full-hunt completion rates.

Exact starter/level8/novice examples for `BOSS-AUDIT-101`, world `(7,2)` (all details in `metrics.json`):

- `audit:BOSS-AUDIT-101:questingBeast`: playerHP148, bossHP2737, boss base damage81; player-death at3.50s; boss remaining2675; hit log `[{"t": 1.4500000000000002, "damage": 77, "hp": 71}, {"t": 2.45, "damage": 66, "hp": 5}, {"t": 3.5, "damage": 5, "hp": 0}]`.
- `audit:BOSS-AUDIT-101:voidWalker`: playerHP118, bossHP712, boss base damage57; player-death at4.60s; boss remaining670; hit log `[{"t": 2.8000000000000003, "damage": 57, "hp": 61}, {"t": 3.45, "damage": 38, "hp": 23}, {"t": 4.6000000000000005, "damage": 23, "hp": 0}]`.
- `audit:BOSS-AUDIT-101:psychicCrystal`: playerHP118, bossHP684, boss base damage57; player-death at4.80s; boss remaining558; hit log `[{"t": 2.4000000000000004, "damage": 47, "hp": 71}, {"t": 3.45, "damage": 47, "hp": 24}, {"t": 4.800000000000001, "damage": 24, "hp": 0}]`.
- `audit:BOSS-AUDIT-101:astralWorm`: playerHP136, bossHP2380, boss base damage70; player-death at3.80s; boss remaining2191; hit log `[{"t": 1.4500000000000002, "damage": 57, "hp": 79}, {"t": 2.6500000000000004, "damage": 57, "hp": 22}, {"t": 3.8000000000000003, "damage": 22, "hp": 0}]`.

**Counter-policy sensitivity:** dodging/circling prolonged survival in many encounters but sacrificed damage and was not uniformly better. Crystal is a useful human follow-up: some novice melee runs win while adaptive runs lose. The current bot is not qualified to declare the fight unfair or recommend a blanket nerf.

**Telegraph/reaction opportunities (source-grounded, not pixel measurements):** `src/monster-pack.ts:522` gives boss damage×.85, windup×1.2, cooldown×1.25, gap×1.35. Walker has overlapping independent effect warnings in `:780–795`: rend.48s, beam.35s, horizon.65s, constellation1.1s, nova charge2.3s, dash warning.28s and1s damaging trails. A350ms reaction policy can miss a280ms dash warning; continual movement is a separate defense. Nova nominal radius7 means a14-tile diameter footprint, not “whole world”; bounds/terrain behavior are regression-tested. Morphling's own timings are in `src/listener-morph.ts:24–39,64–86`: lunge.6s, beams.7s, cables.8s, jaw.65+.45s, sink1.3s, four9-tile beams and up to eight18-tile cables. These custom timers are not direct applications of the shared pack windup multiplier. Rendered warning contrast, occlusion, camera framing, touch reaction time and sound cues remain untested here.

## Lifecycle, targetability and bounds

**No reproduced correctness blocker in this pass.** 335 targeted existing tests passed, sequential test concurrency1: `regression.tap`186/186, `extra-regression.tap`149/149. These are real executed tests, not inferred from source. Some tests use forced attacks, inflated HP, stub worlds or boosted encounter chances; they establish invariants, not balance. Relevant coverage includes:

- World hunt spawning/pursuit, fleeing geometry, retained encounters, four tries, death/rematch and wounds: `tests/world-beasts.test.ts`, `world-beast-pursuit.test.ts`, `beast-continuation.test.ts`, `beast-tries-345.test.ts`, `beast-wounds-353.test.ts`, `beast-wounds-429.test.ts`, `beast-baseline-rematch.test.ts`. Production wound storage is `src/game.ts:3089–3097`. Current Walker dungeon chance is0 (`src/world-beasts.ts:90` vicinity), while pre-existing hunts continue; no claim that new Walker dungeon spawns are expected.
- Walker full production loop attack completion, bounded cleanup, pause, legal grounded positions, scars, routing and ocean variants: `void-walker-game-loop.test.ts`, `void-walker-routing.test.ts`, `void-walker-combat.test.ts`, `void-walker-terrain.test.ts`, `beast-ocean.test.ts`.
- Astral native encounter construction, mounted companion ownership/retreat, Wayglass retirement: `astral-natural-encounters.test.ts`, `astral-world-retreat.test.ts`, `astral-worm-retreat.test.ts`, `astral-worm-game-mount.test.ts`. The natural-encounter tests deliberately raise Aperture and some temporarily boost spawn chance, so they do not establish natural rarity or realistic-balance outcomes.
- Listener mirror clone caps, capture/return behavior, Morphling sink targetability/recovery, worms, wall movement, native hall entry/exit: `listener-mirror-369.test.ts`, `listener-morph-385.test.ts`, `listener-arena-375.test.ts`. Crystal wave/grab/targetability coverage: `crystal-401.test.ts`, `crystal-waves-405.test.ts`, `crystal-437.test.ts`.

Observed pack-effects maximum 36 (cap48 at `src/monster-pack.ts:2727`); peak live mirror clones 8 (cap8 at `src/listener-mirror.ts:22,40`); peak live Morphling worms 5 (cap8 at `src/listener-morph.ts:37`). Peak projectiles 46 is a measured count, not proof of a universal cap or device performance. No matrix case hit180s timeout, nonfinite state or retreat before death/kill; this does **not** verify long-run patience/retreat via balance runs—the separate regression suite covers those fixtures.

## Remaining uncertainty / recommended next evidence

No manual/mobile play, no screenshots or telegraph-pixel footprint validation, no organically progressed save, no real ocean balance, no late optimized glyph/echo/constellation build, no naturally generated dungeon combat obstacle matrix, and no four-life end-to-end player-policy hunt completion. Those are meaningful gaps; do not call this comprehensive player-feel certification. Natural rarity, hidden reload timing edge cases and infinite-world retreat routes were not exhaustively sampled. Best next authorized test would use an organically progressed save plus actual mobile play on Questing/Walker and Crystal, then compare human-readable warnings and successful counterplay. No source or production change is recommended solely from these bot losses.

Read context: AGENTS, AGENT_CONTEXT, relevant CODE/BOUNDARY lifecycle/pacing/Listener/Walker sections of HERMES_PROJECT_FIELD_GUIDE, narrative-bible opening/ambiguity rules, Void Walker design record and source transcript. The audit does not reinterpret unresolved lore or claim the historical release251 handoff is current deployment evidence.

## Reproduction

From the existing pinned checkout, run sequentially:

```sh
node /tmp/ic-audit-cloud/bosses/measure.mjs > /tmp/ic-audit-cloud/bosses/measure.log 2>&1
node /tmp/ic-audit-cloud/bosses/array.mjs > /tmp/ic-audit-cloud/bosses/array.log 2>&1
python3 /tmp/ic-audit-cloud/bosses/report.py
```

`metrics.json` and `array-metrics.json` are final corrected runs. Intermediate fixture validation runs were overwritten; final Far Array includes the production post-spawn tuning and ten relays. Harnesses do not modify the repository. No permission-denied action occurred in this subtask.

**Repeatability check:** reran all 288 final encounters sequentially on Node v24.22.1. Both JSON outputs were byte-identical (`cmp` exit 0) to `metrics-repeat-reference.json` and `array-repeat-reference.json`; logs are `repeat-world.log` and `repeat-array.log`. Exact regression commands are in `regression-commands.txt`.
