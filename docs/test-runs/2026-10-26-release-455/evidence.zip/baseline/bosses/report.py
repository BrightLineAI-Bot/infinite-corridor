import json,statistics,collections,pathlib
p=pathlib.Path('/tmp/ic-audit-cloud/bosses');w=json.loads((p/'metrics.json').read_text());a=json.loads((p/'array-metrics.json').read_text())
s='''# World-boss and Far Array headless audit — release 455

Pinned source: `04c11a0d3b73eeb9c767e9548cd3724c92a8dba9`. Read-only repository; all harnesses/results are under `/tmp/ic-audit-cloud/bosses`. No fixes, commits, pushes, workflows, secrets or environment-variable reads. Final git status was clean.

## Evidence and limits

This is **scripted headless production `Game.update`, not human play**. The matrix contains 216 world-beast/Questing encounters and 72 Far Array encounters. Seeds: `BOSS-AUDIT-101`, `BOSS-AUDIT-202`, `BOSS-AUDIT-303`. Each kind uses levels 8/20; two builds; two input policies. Simulation step 50 ms, stopping at first death, boss kill, retreat, nonfinite state, or 180 seconds. No health/damage/invulnerability cheats. Actual damage, attack selection, enemy AI, stamina, dodge, potions and targeting run in the production game.

**Synthetic setup, not naturally earned:** XP is granted through `awardExperience` to reach each level, then all earned stat points are allocated round-robin Might/Vigor/Finesse/Resolve/Focus through `Game.allocate`. Starter gear is unchanged; rank3 gear uses `upgradeEquipment` three times per slot against fixture-granted spheres, which are removed afterward. This yields primary/tool/armor power 6/3/1 versus 9/6/4. No glyphs, echoes, constellation choices, advanced spell unlocks or rare loot: these are conservative valid builds, not representative optimized endgame builds. Three default draughts; adaptive policy can use them. World beasts get their minimum natural Aperture-tier threshold (tiers3–8), but spawn is directly enrolled, **not** a natural encounter-frequency measurement. Far Array uses Aperture90, Gate2, ten synthetic answered relays and a synthetic prior Listener clear; open/walled choices match restore/sever. Far Array `tuneArrayBoss` is applied after creation, as `Game.loadArea` does at `src/game.ts:2137`.

World arena is a synthetic unobstructed 32×32 floor bounded by walls, at section `(7,2)`, player `(14,16)`, boss `(18,16)`. Boss IDs: `audit:<seed>:<kind>`. Array uses the native `generateListenerArena` map, ID `far-array:<seed>:arena1`; boss IDs end `:listener` or `:guardian`; player/boss repositioned to the same coordinates for a controlled start. Native hall geometry/pylons retained. No ocean loadout in these balance measurements.

Novice policy approaches within1.2 tiles, presses melee every0.5s, dodges every4s, and uses neither tools nor potions. Adaptive policy reads current attack-state (a nonvisual oracle), reacts after350ms, circles/backs away, requests dodge at least1.3s apart, melee every0.3s, tool every0.8s, spell every4s, potion below50% HP. Stamina/cooldown rules still apply. It does not learn counters, jump shockwaves, prioritize summons, avoid every individual effect, or infer telegraph pixels. Therefore “adaptive” is a policy name, **not** proof of skilled play; it sometimes performs worse than simple melee. Movement near arena edges steers inward, never teleports. Not a mobile-input or rendering/readability audit.

Raw JSON records contain every setup, derived player stat, gear, starting boss HP/damage, hit times and capped HP losses, attack selections, remaining HP, targetability duration and peak actors/effects/projectiles. Fatal hits are HP-clipped, not raw overkill. Array death frames can include recovered-area actors in generic actor maxima; mirror/worm maxima remain separately measured. Do not treat repeated seeds as independent statistical samples or these outcomes as human win probabilities.

## Matrix outcomes

Time is time to **terminal outcome**, not TTK unless the boss actually died. Each row contains12 cases (3 seeds×2levels×2builds).

| Boss | Policy | Boss kills/12 | Time min/median/max (s) | Median boss HP remaining | Peak live actors / pack effects / shots |
|---|---|---:|---|---:|---|
'''
for r in [w,a]:
 for k in dict.fromkeys(x['kind'] for x in r):
  for mode in ['novice','adaptive']:
   q=[x for x in r if x['kind']==k and x['mode']==mode];ts=[x['seconds'] for x in q]
   s+=f"| {k} | {mode} | {sum(x['outcome']=='boss-kill' for x in q)} | {min(ts):.2f}/{statistics.median(ts):.2f}/{max(ts):.2f} | {statistics.median(max(0,x['remainingBossHp'])/x['bossHp']*100 for x in q):.1f}% | {max(x['peakAlive'] for x in q)} / {max(x['peakFx'] for x in q)} / {max(x['peakShots'] for x in q)} |\n"
s+='\nOutcome totals: world '+str(dict(collections.Counter(x['outcome'] for x in w)))+'; Array '+str(dict(collections.Counter(x['outcome'] for x in a)))+'.\n'
s+='''
## Reproducible player-feel signals (not correctness defects)

**High-priority balance review, not a blocker:** the Questing Beast and Walker leave short novice learning windows on these lean builds. Owner direction deliberately makes Questing dominate other beasts; `src/world-beasts.ts:397–413` specifies the level8 floor and60 damage reference, and `src/questing-beast.ts:47–48` enforces1.15× dominance. This is not automatically a bug. The four-try/wound-carryover contract also means a first-life loss is not a failed hunt. This matrix stops at first death and cannot estimate full-hunt completion rates.

Exact starter/level8/novice examples for `BOSS-AUDIT-101`, world `(7,2)` (all details in `metrics.json`):

'''
for k in ['questingBeast','voidWalker','psychicCrystal','astralWorm']:
 x=next(x for x in w if x['kind']==k and x['seed']=='BOSS-AUDIT-101' and x['level']==8 and x['loadout']=='starter' and x['mode']=='novice')
 s+=f"- `{x['id']}`: playerHP{x['playerHp']}, bossHP{x['bossHp']}, boss base damage{x['bossDamage']}; {x['outcome']} at{x['seconds']:.2f}s; boss remaining{x['remainingBossHp']}; hit log `{json.dumps(x['hitsTaken'])}`.\n"
s+='''
**Counter-policy sensitivity:** dodging/circling prolonged survival in many encounters but sacrificed damage and was not uniformly better. Crystal is a useful human follow-up: some novice melee runs win while adaptive runs lose. The current bot is not qualified to declare the fight unfair or recommend a blanket nerf.

**Telegraph/reaction opportunities (source-grounded, not pixel measurements):** `src/monster-pack.ts:522` gives boss damage×.85, windup×1.2, cooldown×1.25, gap×1.35. Walker has overlapping independent effect warnings in `:780–795`: rend.48s, beam.35s, horizon.65s, constellation1.1s, nova charge2.3s, dash warning.28s and1s damaging trails. A350ms reaction policy can miss a280ms dash warning; continual movement is a separate defense. Nova nominal radius7 means a14-tile diameter footprint, not “whole world”; bounds/terrain behavior are regression-tested. Morphling's own timings are in `src/listener-morph.ts:24–39,64–86`: lunge.6s, beams.7s, cables.8s, jaw.65+.45s, sink1.3s, four9-tile beams and up to eight18-tile cables. These custom timers are not direct applications of the shared pack windup multiplier. Rendered warning contrast, occlusion, camera framing, touch reaction time and sound cues remain untested here.

## Lifecycle, targetability and bounds

**No reproduced correctness blocker in this pass.** 335 targeted existing tests passed, sequential test concurrency1: `regression.tap`186/186, `extra-regression.tap`149/149. These are real executed tests, not inferred from source. Some tests use forced attacks, inflated HP, stub worlds or boosted encounter chances; they establish invariants, not balance. Relevant coverage includes:

- World hunt spawning/pursuit, fleeing geometry, retained encounters, four tries, death/rematch and wounds: `tests/world-beasts.test.ts`, `world-beast-pursuit.test.ts`, `beast-continuation.test.ts`, `beast-tries-345.test.ts`, `beast-wounds-353.test.ts`, `beast-wounds-429.test.ts`, `beast-baseline-rematch.test.ts`. Production wound storage is `src/game.ts:3089–3097`. Current Walker dungeon chance is0 (`src/world-beasts.ts:90` vicinity), while pre-existing hunts continue; no claim that new Walker dungeon spawns are expected.
- Walker full production loop attack completion, bounded cleanup, pause, legal grounded positions, scars, routing and ocean variants: `void-walker-game-loop.test.ts`, `void-walker-routing.test.ts`, `void-walker-combat.test.ts`, `void-walker-terrain.test.ts`, `beast-ocean.test.ts`.
- Astral native encounter construction, mounted companion ownership/retreat, Wayglass retirement: `astral-natural-encounters.test.ts`, `astral-world-retreat.test.ts`, `astral-worm-retreat.test.ts`, `astral-worm-game-mount.test.ts`. The natural-encounter tests deliberately raise Aperture and some temporarily boost spawn chance, so they do not establish natural rarity or realistic-balance outcomes.
- Listener mirror clone caps, capture/return behavior, Morphling sink targetability/recovery, worms, wall movement, native hall entry/exit: `listener-mirror-369.test.ts`, `listener-morph-385.test.ts`, `listener-arena-375.test.ts`. Crystal wave/grab/targetability coverage: `crystal-401.test.ts`, `crystal-waves-405.test.ts`, `crystal-437.test.ts`.

'''
s+=f"Observed pack-effects maximum {max(x['peakFx'] for x in w+a)} (cap48 at `src/monster-pack.ts:2727`); peak live mirror clones {max(x['peakMirrors'] for x in a)} (cap8 at `src/listener-mirror.ts:22,40`); peak live Morphling worms {max(x['peakWorms'] for x in a)} (cap8 at `src/listener-morph.ts:37`). Peak projectiles {max(x['peakShots'] for x in a)} is a measured count, not proof of a universal cap or device performance. No matrix case hit180s timeout, nonfinite state or retreat before death/kill; this does **not** verify long-run patience/retreat via balance runs—the separate regression suite covers those fixtures.\n"
s+='''
## Remaining uncertainty / recommended next evidence

No manual/mobile play, no screenshots or telegraph-pixel footprint validation, no organically progressed save, no real ocean balance, no late optimized glyph/echo/constellation build, no naturally generated dungeon combat obstacle matrix, and no four-life end-to-end player-policy hunt completion. Those are meaningful gaps; do not call this comprehensive player-feel certification. Natural rarity, hidden reload timing edge cases and infinite-world retreat routes were not exhaustively sampled. Best next authorized test would use an organically progressed save plus actual mobile play on Questing/Walker and Crystal, then compare human-readable warnings and successful counterplay. No source or production change is recommended solely from these bot losses.

Read context: AGENTS, AGENT_CONTEXT, relevant CODE/BOUNDARY lifecycle/pacing/Listener/Walker sections of HERMES_PROJECT_FIELD_GUIDE, narrative-bible opening/ambiguity rules, Void Walker design record and source transcript. The audit does not reinterpret unresolved lore or claim the historical release251 handoff is current deployment evidence.

## Reproduction

From the existing pinned checkout, run sequentially:

```sh
node /tmp/ic-audit-cloud/bosses/measure.mjs > /tmp/ic-audit-cloud/bosses/measure.log 2>&1
node /tmp/ic-audit-cloud/bosses/array.mjs > /tmp/ic-audit-cloud/bosses/array.log 2>&1
python3 /tmp/ic-audit-cloud/bosses/report.py
```

`metrics.json` and `array-metrics.json` are final corrected runs. Intermediate fixture validation runs were overwritten; final Far Array includes the production post-spawn tuning and ten relays. Harnesses do not modify the repository. No permission-denied action occurred in this subtask.
'''
(p/'REPORT.md').write_text(s)
