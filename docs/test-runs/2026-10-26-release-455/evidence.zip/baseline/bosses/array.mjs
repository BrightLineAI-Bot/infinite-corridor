import {Game,awardExperience,characterStats} from '/tmp/ic-audit-cloud/repo/src/game.ts';
import {freshSave} from '/tmp/ic-audit-cloud/repo/src/types.ts';
import {WORLD_BEAST_IDS} from '/tmp/ic-audit-cloud/repo/src/world-beasts.ts';
import {upgradeEquipment} from '/tmp/ic-audit-cloud/repo/src/items.ts';
import {ensureFarArray, runBossSpawn, tuneArrayBoss} from '/tmp/ic-audit-cloud/repo/src/far-array.ts';
import {generateListenerArena} from '/tmp/ic-audit-cloud/repo/src/listener-arena.ts';
import {writeFileSync} from 'node:fs';
const rows=[];
for(const seed of ['BOSS-AUDIT-101','BOSS-AUDIT-202','BOSS-AUDIT-303'])for(const level of [8,20])for(const loadout of ['starter','rank3'])for(const mode of ['novice','adaptive'])for(const kind of ['listener-open','listener-walled','guardian']){
 const s=freshSave();s.seed=seed;s.perception.aperture=90;for(let l=1;l<level;l++)awardExperience(s,s.nextXp);const g=new Game(s,0);
 // Allocate earned points evenly, not max stats. No gear/items conjured: original starter kit and three draughts.
 let i=0;while(s.statPoints)g.allocate(['Might','Vigor','Finesse','Resolve','Focus'][i++%5]);if(loadout==='rank3'){s.materials.weaponSphere=30;s.materials.armorSphere=30;for(const slot of ['primary','secondary','armor'])for(let n=0;n<3;n++)upgradeEquipment(s,slot);s.materials.weaponSphere=0;s.materials.armorSphere=0;}g.refreshDerivedStats();g.deathPause=true;
 const W=32,unusedMap={width:W,height:W,entry:{x:16,y:16},objects:[],enemySpawns:[],tiles:Array.from({length:W*W},(_,i)=>{const x=i%W,y=Math.floor(i/W),blocked=x===0||y===0||x===31||y===31;return{x,y,kind:blocked?'wall':'floor',blocked,elev:0}})};
 const map=generateListenerArena(seed,`far-array:${seed}:arena1`);
 Object.assign(g,{area:'dungeon',rx:7,ry:2,map,enemies:[],effects:[],packEffects:[],projectiles:[],paused:false,seaHazards:null,storm:null});
 Object.assign(g.player,{x:14,y:16,hp:s.maxHp,stamina:s.maxStamina,invulnerableUntil:0,dodgeUntil:0});
 s.relayNetwork={version:1,nodes:{}};s.relayNetwork.nodes=Object.fromEntries(Array.from({length:10},(_,i)=>[`audit-relay-${i}`,{choice:kind==='listener-walled'?'sever':'restore'}]));const f=ensureFarArray(s);f.gate=2;f.listeners=1;f.quiet=false;f.activeRun={id:`far-array:${seed}:arena1`,gate:2,listener:kind!=='guardian',kind:'arena',returnPoint:{rx:7,ry:2,x:14,y:16}};s.session.activeDungeonId=f.activeRun.id;
 const spawn=runBossSpawn(s,{x:18,y:16});if(kind.startsWith('listener')){spawn.listenerPhase=kind.split('-')[1];spawn.listenerForm=spawn.listenerPhase;}
 const e=g.createEnemyFromSpawn(spawn,'dungeon');tuneArrayBoss(e,s,characterStats(s),e.farArrayBoss);e.aggro=true;g.enemies=[e];
 const row={seed,level,loadout,mode,kind,aperture:s.perception.aperture,id:e.id,rx:7,ry:2,playerStart:[14,16],bossStart:[18,16],playerHp:s.maxHp,stats:{...s.stats},gear:JSON.parse(JSON.stringify(s.equipment)),derived:characterStats(s),bossHp:e.maxHp,bossDamage:e.damage,damageTaken:0,damageDealt:0,hitsTaken:[],attacks:{},peakEnemies:1,peakAlive:1,peakMirrors:0,peakWorms:0,peakFx:0,peakShots:0,untargetableSeconds:0,retreat:false,outcome:'timeout'};
 let lastAttack='',reactionAt=Infinity,lastDodge=-1e9;
 for(let frame=1;frame<=3600;frame++){
  const now=frame*50,dist=Math.hypot(e.x-g.player.x,e.y-g.player.y),dx=e.x-g.player.x,dy=e.y-g.player.y;
  const threat=e.pack?.attack||e.morph?.move||e.mirror?.move||'';
  if(threat&&threat!==lastAttack){row.attacks[threat]=(row.attacks[threat]||0)+1;reactionAt=now+350;}lastAttack=threat;
  let x=dist>1.2?dx:0,y=dist>1.2?dy:0;
  const evade=mode==='adaptive'&&threat&&now>=reactionAt;
  if(evade){x=-dy/(dist||1)+ (dist<3?-dx/(dist||1):0);y=dx/(dist||1)+(dist<3?-dy/(dist||1):0);}
  // Keep steering away from boundary, no teleport or forced hit/invulnerability.
  if(g.player.x<3)x=Math.max(0,x)+1;if(g.player.x>28)x=Math.min(0,x)-1;if(g.player.y<3)y=Math.max(0,y)+1;if(g.player.y>28)y=Math.min(0,y)-1;
  const actions=new Set();if(frame%(mode==='novice'?10:6)===0)actions.add('attack');
  if(mode==='adaptive'){if(frame%16===0)actions.add('tool');if(g.player.hp<s.maxHp*.5&&frame%20===0)actions.add('potion');if(evade&&now-lastDodge>1300){actions.add('dodge');lastDodge=now;}if(frame%80===0)actions.add('spell');}
  else if(frame%80===0)actions.add('dodge');
  const hp=g.player.hp,bhp=e.hp;
  g.update(.05,{state:{x,y},consume(k){return actions.delete(k)},held:()=>false,reset(){}},now);
  const died=!!s.lastDeath||!g.enemies.includes(e);const endHp=died?0:g.player.hp; if(endHp<hp){row.damageTaken+=hp-endHp;row.hitsTaken.push({t:frame*.05,damage:hp-endHp,hp:endHp});}
  row.damageDealt+=Math.max(0,bhp-e.hp);row.peakAlive=Math.max(row.peakAlive,g.enemies.filter(q=>!q.dead&&q.hp>0).length);row.peakMirrors=Math.max(row.peakMirrors,g.enemies.filter(q=>!q.dead&&q.mirrorClone).length);row.peakWorms=Math.max(row.peakWorms,g.enemies.filter(q=>!q.dead&&q.morphWorm).length);row.peakEnemies=Math.max(row.peakEnemies,g.enemies.length);row.peakFx=Math.max(row.peakFx,g.packEffects.length);row.peakShots=Math.max(row.peakShots,g.projectiles.length);if(e.untargetable)row.untargetableSeconds+=.05;
  row.seconds=frame*.05;row.remainingBossHp=e.hp;row.remainingPlayerHp=endHp;
  if(![g.player.x,g.player.y,e.x,e.y,e.hp].every(Number.isFinite)){row.outcome='nonfinite';break;}
  if(g.fallen||g.player.hp<=0||g.rx!==7||g.ry!==2||s.lastDeath||!g.enemies.includes(e)){row.outcome='player-death';break;}if(e.dead||e.hp<=0){row.outcome='boss-kill';break;}if(e.retreating){row.outcome='boss-retreat';row.retreat=true;break;}
 }
 rows.push(row);writeFileSync('/tmp/ic-audit-cloud/bosses/array-metrics.json',JSON.stringify(rows,null,2));console.log(JSON.stringify({kind,seed,level,loadout,mode,outcome:row.outcome,t:row.seconds,bhp:row.remainingBossHp,php:row.remainingPlayerHp,peak:[row.peakEnemies,row.peakFx,row.peakShots]}));
}
