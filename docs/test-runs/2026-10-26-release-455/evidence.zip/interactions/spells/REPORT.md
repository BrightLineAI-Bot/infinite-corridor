# Spell skill and glyph interactions

Pinned455/04c11a0d3b73eeb9c767e9548cd3724c92a8dba9, read-only production code. Matrix creates synthetic flat scratch arenas at ApertureInfiniteIII, grants maximum learned ranks for eligibility and trainingtargetHP10000; this is correctness testing, not balance or naturalprogression.

Catalog6spells:CinderDart,EmberRing,GraveSun,ShadowClone,GravityWell,Stillpoint.6activedisciplines:EmberForm,Quickening,AerialStep,VeilGuard,ForceChannel,RiftStep. All12catalog keys in results.json.

matrix.mjs:12standalone casts,132ordered distinct A/Bpairs (12×11),12duplicate-slot assignmentchecks. All156pass. Allstandalone damagingfields strike explicitly aimed target; ShadowClone deployed/charged and recorded, RiftStep moves, timed skills activate. Paircases execute both slots in actual Game methods/update, togglepresets twice preservingcooldowns, JSON/export/migrate/Gameconstruction with cooldown equality, and600updates=30simseconds for finite/nonnegative cooldowns/positions/HP, allbuffs/cooldowns expire. All20reachable attributePairings represented; force+force cannot occur with current distinctcastable catalog(oneForcecastable, duplicates prohibited), so21definedPairing entries are not21executablepairs. Single active timedskill means later timedskill replaces earlier by design; not simultaneousbuffstack assertion.

Initial CinderDart standalone assertion was a fixture mistake: un-aimed field spawns atplayercenter,radius1.25, while target2tilesaway. Corrected explicit pendingAim, reranall156clean; initial-results-target-not-aimed.json/log preserved, not a productdefect. Otherfivefields had wider radii so initially hit. This is not an autoaimbug.

glyph-cross.mjs:396spellconfigs(6spells×[baseline+10singleglyphs+55unordered2glyphcombinationsincldoubles])+66skillconfigs(6skills×[baseline+10singles]). All462complete with finite nonnegative measured damage/noexceptions; outputs record actual cooldowns, declaredhostmods, fields/radii/damage, enemyburn/slow, skillactivation/RiftInfusion and actual weaponhit. This is broadsmoke with effectmetrics, not oraclevalidation of everyglyphproc. Existingfocused51tests include ShadowClonecopy/swap/blockedplacement/heldcharge and hostilefieldinteraction checks, alreadyincludedelsewhere; do not doublecount.

## Confirmed defect Spell glyph recovery modifiers ignored by Shadow Clone

Normalvalid input: createeligiblefreshsave, put ShadowClone inA andBempty, acquire/socket Swift toshadow-clone index0 throughsocketGlyph, castSlot('a'). UI glyph descriptions promise Swift30%fasterspellrecovery; actualcooldown16s, expected16×.7=11.2. Heavy promises25%longerrecovery; actual16, expected20. Baseline16. CinderDartpositivecontrols baseline2.5,Swift1.75,Heavy3.125.21/66ShadowClone configurations disagree with declared cooldown; other330spellconfigs agree. See glyph-cross.json/log rowsidshadow-clone andglyphs[]/[swift]/[heavy]. No stat/armor/pairing cooldown reductions active inthese fixtures.

Source src/game.ts4281dispatchesClonebeforeglyphLoadout;castShadowClone4338uses pairing/armor but neverhostglyph cooldown. Ordinaryfieldcast4317multiplies glyphs.mods.cooldown. src/glyphs.ts25–26definesHeavy/Swiftspellcontract;main.ts2491–2505offersspellglyphs/descriptionincludingClone without warning. Suggestedfixarea: applycompatiblehostcooldownmods toClone, or explicitly disallow/describeunsupportedglyphs; regressionpositivecontrol. No codefix applied. OtherCloneglyph effects(Echo/pulse-onlyradius/ignition) need separate designcontract; don't extrapolate this proof toall10glyphs.

Astral Cloak is not a literalitem/spell/skillname in searchedsrc/tests/docs catalogs. Awaituserclarification; do NOTequateShadowClone or enemyAstralMount withAstralCloak. EnemyAstralMount is not a playercastable.

## Limitations

No full12×10×26Echo×30constellation×gearCartesian product; no everycontinuous statroll; no separatevisualUI; no organicallyprogressedsave; no endtoenddeath/revive for everypair; no allterrain/mount/projectile/vehicle combinations. Pairresumes verifycooldowns, not equivalence ofall transientclone/field state. Only30seconds perpair and3seconds per spellglyphconfig. TargetHP10000/zeroattackin glyphcross is a durabilityfixture, not a balanceclaim. Exactcommands node matrix.mjs and node glyph-cross.mjs; sourceimports fixed tocleanpinnedcheckout with portable runner providedseparately.
