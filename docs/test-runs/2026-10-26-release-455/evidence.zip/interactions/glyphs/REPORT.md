# Glyph Echo and constellation interaction component audit

**Release:** 455. **Pinned source:** `04c11a0d3b73eeb9c767e9548cd3724c92a8dba9`, checkout `/tmp/ic-audit-cloud/repo`.

This component report synthesizes the already executed harnesses and preserved results under `/tmp/ic-interactions/glyphs/`. No additional tests were run during synthesis. No source, original audit, or original archive was edited. Bare artifact names below refer to this component directory; source references refer to the pinned checkout.

## Summary and evidence strength

**One confirmed MINOR interaction defect:** an already-applied slow keeps its old effective speed multiplier when Spinner's Web replaces its stored slow factor with a stronger value. Targeted production-loop evidence records factor/speed `0.6/0.6` becoming `0.5/0.6` instead of `0.5/0.5`.

All broad custom rows completed their implemented assertions: **444 glyph, 352 Echo, 21 armor, 300 conservation, and 330 constellation-node × glyph rows**. These totals describe executed rows, not unique builds or fully verified gameplay semantics. In particular, the glyph matrix primarily asserts that something hits and selected numerical state is finite; the Echo matrix primarily asserts loadout selection and finite state. Neither asserts every expected proc, duration, target, counter, immunity, chain, healing amount or interaction. A targeted defect therefore coexists with zero broad-matrix assertion failures.

The preserved `regression.log` records **36 existing tests passing, zero failing**, duration 4.181 seconds. These are focused reruns overlapping the original full-suite baseline, not 36 new distinct repository tests.

## Finite catalog and supported hosts

### Glyphs and socket limits

There are **10 glyph IDs**, all defined for melee, tool, spell, armor and Aperture-skill hosts. Armor provides steady bonuses, not the weapon on-hit behavior. An active skill provides its own duration/cooldown/reach/charge modifiers or infuses weapon/tool hits. Sources: `src/glyphs.ts:13–15,19–31,36–81`.

| ID and display name | Melee | Tool | Spell |
|---|---|---|---|
| `ignite` Ignite | Burn 3s | Burn 2s | Burn 1.5s per pulse |
| `chain` Chain | One arc at 50% | Two arcs at 45% | One arc at 40% |
| `pierce` Pierce | Reach ×1.3 | Pierce value +3 | Radius ×1.3 |
| `echo` Echo | Repeat after250ms at50% | Follow-up after150ms at60% | Recast at50% |
| `leech` Leech | Heal12%, minimum2% maxHP | Heal8%, minimum1.2% maxHP | Heal5%, minimum0.8% maxHP |
| `heavy` Heavy | Damage×1.35, cooldown×1.25, stagger | Same modifiers and stagger | Damage×1.35, cooldown×1.25 |
| `swift` Swift | Damage×0.85, cooldown×0.75 | Same | Damage×0.85, cooldown×0.7 |
| `volatile` Volatile | Kill burst radius1.6, damage6+40% | Impact burst radius1.2, damage50% | Kill burst radius1.6, damage6+40% |
| `tether` Tether | Slow factor0.6 for2s | Slow factor0.6 for1.5s | Pull toward origin, up to0.35 tile |
| `still` Still | Stun0.5s | Stun0.6s | Stun0.4s |

These are catalog/source contracts, not claims that each cell received an independent semantic assertion. Boss/elite status halves the Still/Grave Tether stun scaling in `glyphHit`; the generic fixture's `boss` Boolean is not a full real-boss immunity/AI matrix (`glyphs.ts:164–175`).

Gear has **1 common, 2 rare, 2 epic, 3 relic sockets**, plus exactly one optional smith extra socket, making the maximum **4**. Spells and `skill:<id>` hosts have **2 sockets**. Gear layout hosts are only `melee`, `tool`, `armor`; saved layouts preserve up to4 positions. Socketing returns prior glyphs to the pouch. Source: `glyphs.ts:14–15,96–105,116,214–235`.

| Glyph | Armor bonus per copy | Armor cap | Skill-host behavior |
|---|---|---|---|
| Ignite | Magic damage +12% | +36% | Infuse burning |
| Chain | Spell/skill cooldown reduction12% | 36% | Infuse arcs |
| Pierce | Attack/shot readiness reduction12% | 36% | Cooldown×0.9; Rift reach+2 |
| Echo | Skill duration+20% | +60% | Duration×1.25; Rift charge+1 |
| Leech | MaxHP+10% | +30% | Infuse healing |
| Heavy | Damage reduction+5% | +15% | Duration×1.35; Rift reach+1 |
| Swift | Move speed+8% | +24% | Cooldown×0.75 |
| Volatile | Melee damage+10% | +30% | Infuse kill/shot bursts |
| Tether | Stamina regeneration+25% | +75% | Infuse slowing |
| Still | Dodge cost reduction20% | 60% | Infuse freezing |

Armor bonuses add then cap; skill multiplicative modifiers multiply per glyph. Skill infusion applies while a timed skill remains active, or for **4 seconds after Rift Step**. The 330-row node matrix sockets its glyph into **melee**, not the skill host; skill-socket behavior has narrower existing-test coverage, not a full custom 10-glyph × every-skill × every-pair matrix (`glyphs.ts:49–81`).

Eight named resonances are finite and source-defined (`glyphs.ts:84–93`):

| ID and name | Pair | Additional rule |
|---|---|---|
| `ember-choir` Ember Choir | Ignite + Echo | Echo damage doubles on burning targets |
| `wildfire` Wildfire | Ignite + Chain | Chained targets ignite |
| `storm-lattice` Storm Lattice | Chain + Volatile | Arc ends in a small burst |
| `afterimage` Afterimage | Pierce + Echo | Echo share becomes full strength |
| `grave-tether` Grave Tether | Tether + Still | Hitting an already slowed target stuns1s, boss-scaled |
| `comet` Comet | Heavy + Volatile | Burst radius×1.6, damage×1.5 |
| `blood-tide` Blood Tide | Leech + Heavy | Leech healing×2 |
| `quickstep` Quickstep | Swift + Leech | Kill restores8 stamina |

Resonance presence uses a set of IDs; duplicate glyphs do not create another named resonance. Modifiers may stack, while several on-hit rules use presence rather than count; Leech explicitly multiplies by copy count (`glyphs.ts:133–144,168`). Do not assume all duplicate glyphs double every proc.

### Creature Echo catalog

There are **26 Echo IDs**. Ordinary equipment allows **3 total notches**; each Echo costs1–3. The Transit Lattice adds a separate base1 Echo slot, up to3 extra slots, once band index13/Infinite III and one Listener clear are reached. The sweep uses one ordinary Echo and, for a pair, one Lattice Echo, so all distinct pairs can be exercised without violating the ordinary notch cap. Sources: `src/echoes.ts:13,31–83`, `src/transit-lattice.ts:16,39–49`.

| ID | Name | Cost | Trigger |
|---|---|---:|---|
| `thunderhorn` | Thunderhorn's Charge | 2 | Dodge |
| `riftLynx` | Lynx Pounce | 2 | Dodge |
| `pallidCrawler` | Pallid Skitter | 1 | Dodge |
| `veilSpinner` | Spinner's Web | 1 | Dodge |
| `strataEel` | Eel's Phase | 2 | Dodge |
| `sunderjaw` | Sunderjaw's Rupture | 2 | Jump landing |
| `gnawingMaw` | Maw's Hunger | 2 | Kill |
| `amalgam` | Flesh Bloom | 1 | Kill |
| `cinderSeraph` | Seraph's Firefall | 2 | Kill |
| `hangedChoir` | Choir's Lament | 2 | Hurt |
| `mirrorShade` | Mirror Swap | 3 | Hurt |
| `lumenWraith` | Wraith Lantern | 2 | Spell |
| `siegeBeetle` | Beetle Mortar | 2 | Every third tool shot |
| `weepingSaint` | Saint's Regard | 3 | Facing nearby foes |
| `listener` | Listener's Answer | 3 | Hurt |
| `questingBeast` | Beast's Spines | 3 | Kill |
| `morphingBlob` | Blob's Spatter | 2 | Hurt |
| `bloblet` | Bloblet Mend | 1 | Kill |
| `tremorWorm` | Worm's Upheaval | 3 | Dodge |
| `wormTentacle` | Tentacle Ember | 1 | Kill |
| `mountainTurtle` | Turtle's Ward | 3 | Hurt |
| `nanobotKnight` | Nanite Seekers | 3 | Kill |
| `lightningGiant` | Giant's Arc | 3 | Kill |
| `psychicCrystal` | Mind Ward | 2 | Hurt |
| `voidWalker` | Rift Upheaval | 2 | Dodge |
| `graveLantern` | Lantern Stillness | 1 | Standing still |

The source currently guarantees an unowned eligible guardian/world-beast Echo and grants none from ordinary kills, summons or no-reward enemies; historical chance comments/constants are not the current drop rule (`echoes.ts:18–27,89–95`). The custom interaction sweep grants ownership directly, so it does not independently measure drops. Existing reruns cover the relevant grant rules.

### Constellation node catalog

Five branches contain **15 modifier/capstone IDs**, each with a primary and secondary form, giving **30 named forms**. A node's secondary choice opens at band index13. The Lattice can hold another learned form beyond the chosen form: base2 passive slots plus up to3 extras. The custom node matrix does **not** set Lattice passives or test simultaneous primary+secondary combinations (`constellation.ts:59–103`; `transit-lattice.ts:16`).

| Branch and active | Node ID | Primary name | Secondary name |
|---|---|---|---|
| Form / `ember-form` | `ember-skin` | Ember Skin | Ember Ward |
| Form / `ember-form` | `colossus` | Colossus | Ember Mend |
| Form / `ember-form` | `cinder-heart` | Cinder Heart | Kindling |
| Motion / `quickening` | `light-feet` | Light Feet | Second Wind |
| Motion / `quickening` | `aerial-step` | Aerial Step | Long Quickening |
| Motion / `quickening` | `slipstream` | Slipstream | Afterimage |
| Veil / `veil-guard` | `thorned-veil` | Thorned Veil | Veil Pulse |
| Veil / `veil-guard` | `sanctuary` | Sanctuary | Long Veil |
| Veil / `veil-guard` | `mirror-veil` | Mirror Veil | Stillwater |
| Force / `force-channel` | `overflow` | Overflow | Wellspring |
| Force / `force-channel` | `amplifier` | Amplifier | Bulwark Channel |
| Force / `force-channel` | `resonant-force` | Resonant Force | Harvest |
| Rift / `rift-step` | `rift-wake` | Rift Wake | Rift Ward |
| Rift / `rift-step` | `fold` | Fold | Quick Fold |
| Rift / `rift-step` | `anchor` | Long Step | Rift Echo |

Source: `constellation.ts:23–40,60–75`. The persisted ID `anchor` means Long Step, not a recall mechanic. A mastered branch may take both capstones, each costing2 points; ranks/modifiers cost1; points are earned every6 Aperture. Respec costs `2 + ceil(pointsSpent/2)` lumen dust and clears ranks, nodes and alternatives (`:19,120–174`). These are source/existing-test contracts; custom fixtures directly assign learned nodes rather than following purchase progression.

## Executed custom coverage and numerical outcomes

### Common fixture

`audit.mjs` and `common.mjs` create fresh production `Game` instances but replace the map with a synthetic flat32×32 dungeon, no exits/objects/spawns, and four `rootBrute` targets at `(11.2,10),(12.8,10),(14,10),(12,11)` with1000HP, damage0, cooldown999, aggrofalse and speed0. Player starts `(10,10)`, HP30, stamina50; relic power4 Verge Cleaver, Needle Caster and Test Mail are injected. Seed is `INTERACTION-GLYPH-455`. This is a mechanics fixture, not ordinary combat, organically earned equipment or boss balance.

Glyph rows run melee, tool and `cinder-dart` spell hosts against bossfalse/true. Each host/tag has74 scheduled configurations: empty,10 singles,55 unordered pairs including duplicates, and8 resonance-pair-plus-Chain triples. Spell rows truncate to two sockets, so the eight extra spell rows repeat existing pair behavior rather than testing three-glyph spells. After attack/cast,60 updates at50ms run for3 simulated seconds. Assertions check selected player/enemy coordinates/resources finite, playerHP not above saved max, final projectiles<150/effects<100/glyphTimers<100, and at least one positive target damage. These are final checks, not continuous peak/cap proofs.

Selected ordinary-target measurements from `results.json` show real changes beyond mere activation:

| Host / glyphs | Cumulative damage to four targets after3s | Other recorded observation |
|---|---|---|
| Melee / none | `[13,0,0,0]` | Baseline |
| Melee / Ignite | `[21,0,0,0]` | Immediate burn true; expired by final sample |
| Melee / Echo | `[20,0,0,0]` | Delayed extra damage |
| Melee / Ignite+Chain | `[21,0,0,15]` | Two targets initially burning |
| Melee / Ignite+Echo | `[35,0,0,0]` | Target still burning at final sample |
| Melee / Leech+Heavy | `[16,0,0,0]` | PlayerHP30→33 |
| Tool / none | `[13,0,0,0]` | One initial projectile |
| Tool / Chain | `[13,6,0,6]` | Additional targets damaged |
| Tool / Ignite+Echo | `[37,0,0,0]` | Additional delayed/burn damage |
| Spell / none | `[20,10,0,20]` | One initial effect |
| Spell / Echo | `[30,20,0,30]` | Two initial effects |
| Spell / Ignite+Echo | `[48,36,0,48]` | Different damage outcome |

Still melee records immediate stun0.5s versus baseline0.22s; a single Tether records a slow present immediately and absent after3s. These individual observations do not establish every resonance or subsequent-hit condition: for example, Grave Tether's one-second bonus requires an already slowed target, not simply the first hit with both glyphs.

Armor's21 rows are empty,10 singles,10 four-of-a-kind stacks on relic armor with one extra socket. Recorded baseline→four-copy results include maxHP60→78 for Leech; damage reduction0.10→0.25 for Heavy; dodge cost15→6 for Still; 0.5s stamina recovery4.5→7.875 for Tether; attack readiness420ms→268.8ms for Pierce; Cinder Dart cooldown2.5s→1.6s for Chain; spell effect damage10→14 for Ignite; melee hit13→17 for Volatile. The four Echo armor glyphs report duration bonus0.6, but this armor loop does not activate a timed skill to measure its duration. Removal asserts every armor bonus returns to zero; JSON migration preserves socket arrays.

Conservation covers3 gear hosts ×10 ordered first glyphs ×10 second glyphs =300 cases. Each saves a layout, applies it20 times, and checks total pouch+equipped glyph count unchanged: **6,000 applications**. Migration also preserves pouch counts. This does not cover spell layouts, every inventory/salvage route or malformed inputs.

Echo rows cover empty,26 singles and325 distinct pairs,352 total. Ownership, Aperture3255 and one Listener are synthetic. The sequence requests dodge/jump, subtracts5HP to trigger hurt detection, creates a one-HP target for a kill, casts Cinder Dart, attempts three tool shots and updates. Finite-state/loadout assertions pass, but there is no per-Echo oracle proving every intended trigger happened or hit the right targets. Firing attempts are not all individually asserted successful.

Constellation rows use seed `NODE-GLYPH455`:15 nodes ×2 forms ×(no glyph+10 melee glyphs)=330. All skill ranks are synthetically maxed, the branch modifier is present, and a capstone is assigned when applicable. Actual skill activation, HP-loss detection, melee, dodge, synthetic one-HP kill and cooldown ticks run. Assertions cover chosen-form predicates, activation, finite numerical state and preservation of the alt choice through JSON migration, not every proc result.

Useful no-glyph numerical records in `constellations.json` include Colossus/Ember Mend duration10.5s versus base7s, with reduction0.15/0; Long Quickening12s versus8s; Long Veil12s versus8s; Second Wind HP20→23; Harvest HP20→24; Resonant Force final remaining7.85s versus6.85s; Amplifier1.5 versus Bulwark reduction0.15; Overflow spell cooldown10→8.75 in the measured one-second window while skill cooldown reaches9, with Wellspring reversing which cooldown reaches8.75; Rift Ward guard timestamp1600 versus1150 from start1000; Fold leaves1 charge, Quick Fold0 with cooldown4.2 versus6. These are fixture outputs, not complete balance evaluations. Recorded Rift x remains10; this report makes no new travel-distance claim from that matrix.

## Confirmed finding G001 MINOR

### Stronger slow changes stored factor but not effective speed

**Area:** Tether glyph combined with Spinner's Web Echo.

**Reproduction preserved in `targeted.mjs`:** Use `arena('SLOW-STACK455')`; socket Tether into melee slot0; grant/activate `veilSpinner`; call `primaryAttack(1000)`; update once at1050. Record target0 state. Request dodge through `Game.update` at1100, then two updates beginning1150. No direct write to target slow or multiplier is used in this targeted sequence.

**Expected:** Spinner's Web's factor0.5 is reflected in effective `speedMultiplier` while the stronger web slow applies. **Actual:** Before, `{factor:0.6,speed:0.6,base:1}`. After, `{factor:0.5,speed:0.6,base:1}`. The current effective slow remains40% rather than the web's50%. The independent control in `/tmp/ic-interactions/core/slow-independent.json` strengthens the comparison: seed `SLOW-INDEPENDENT-false` gives Web alone factor/speed0.5/0.5; `SLOW-INDEPENDENT-true` gives Web after Tether0.5/0.6. Both restore speed1 and clear slow after expiry. These deterministic checks establish the overlap case, not a population frequency or full ordering/duration matrix.

**Evidence:** `targeted.json` key `slow`; `targeted.log`; source contract `src/echoes.ts:35,115` and update `:182`. Tether writes factor0.6 at `src/glyphs.ts:173`; `tickGlyphStatus` at `:198–203` applies the multiplier only when `glyphBaseSpeed` is initially undefined, never recomputing it while a slow remains active. That explains stale effective speed after the factor changes. Production movement consumes `speedMultiplier`, for example `src/monster-pack.ts:2238`; however these fixture enemies have speed0, so this check measures the actual production multiplier state, **not a travelled-distance or visual-motion difference**.

**Suggested fix area:** Recompute the active effective multiplier from an appropriate saved base whenever the winning slow factor changes, without repeatedly multiplying an already-slowed speed. Define overlap/refresh/restoration rules and add both ordering and expiry tests. No fix was applied; other status combinations are not automatically implicated.

## Reproduced behaviors requiring a design decision

### In-flight tool shots use current glyph equipment

Seed `SHOT-GLYPH455`; keep one target at `(14,10)`, fire Needle Caster at1000, change the Ignite socket before impact, then run15 updates beginning1050. Keeping Ignite or adding it after launch both produce targetHP986 with burn `{until:3200,dps:3,tick:0.8000000000000004}`. Removing Ignite after launch yieldsHP987 and no burn. Evidence: `targeted.json` keys `projectile-retain`, `projectile-remove`, `projectile-add`.

This demonstrates impact-time binding of on-hit glyph behavior, not necessarily a defect. `src/game.ts:4748–4749` resolves `this.glyphLoadout(shot.glyphHost)` at impact; `:2471–2474` reads the current save loadout. The preserved evidence does not establish an explicit shot-time snapshot contract. Decide the desired rule before changing behavior; no exploit, frequency or balance impact was quantified.

### Replacing Ember Form does not trigger Cinder Heart's ending burst

Seed `CINDER-END455`; learn Ember Form/Quickening, choose primary Cinder Heart, activate Ember Form, set its remaining duration to0.05s. Natural expiry on the next update damages targets `[12,0,0,12]`. Activating Quickening before that update instead yields `[0,0,0,0]`, active `quickening`. Evidence: `targeted.json` keys `cinder-false`/`cinder-true`.

`constellation.ts:26` says “When Ember Form ends”; runtime `game.ts:4439` replaces `state.active`, while timed expiry invokes `onSkillEnded` at `:4548`; burst implementation is `constellation.ts:204–205`. Whether deliberate replacement should count as ending is unresolved. Preserve as a design-ambiguous behavior, not a confirmed correctness finding, until replacement/cancellation semantics are agreed.

## Inconclusive targeted checks

`MIRROR-FIRST455` attempts normal-enemy damage values10 and999 with Mirror Veil. Both preserved outcomes are playerHP60→53, `mirrored:false`, `fallen:false`, observed at frames25 and95 respectively. It does **not** show a lethal hit or controlled delivered damage999. The harness stops at the first HP change and does not demonstrate a complete subsequent rollback/first-blow outcome. Do not report a lethal-bypass defect from these records. The separate node matrix records a directly subtracted5HP restored to25 with `mirrored:true`; existing tests also cover a nonlethal rollback. Actual lethal-hit behavior remains unestablished by this component.

## Existing regressions and limits

The36 passing titles map to `armor-glyphs-295.test.ts`, `glyphs.test.ts`, `echoes.test.ts`, `echo-grant-337.test.ts`, `constellation.test.ts`, `secondary-passives-359.test.ts`, `skill-glyphs-297.test.ts`. Their assertions include socketing/refunds, selected resonance/proc behavior, armor caps, Echo grants and representative trigger events, constellation points/respec, primary/secondary choices, Rift mechanics and selected skill glyph duration/infusion. The exact executed shell command was not preserved in this component, so filenames identify coverage rather than an asserted historical command line.

Not established: every weapon/spell profile; all four-slot glyph combinations; every skill-glyph pair; all three-plus Echo loadouts or four extra-Lattice combinations; simultaneous passive forms; all proc semantic oracles; real guardian/elite/worldboss immunities; full overlap ordering and expiry; status persistence across every transition/death; player-facing descriptions/rendering; mobile controls; frame timing/performance; natural drop incidence; high-density endurance or an organically progressed build. Bombard and the broader weapon matrix belong to the separate weapon component and are not claimed here.

## Preserved artifacts and rerun entry points

- `audit.mjs` plus its recorded `results.json` and `run.log`: glyph/Echo/armor/conservation sweep.
- `common.mjs`: fixture shared by targeted and node scripts; reading it does not itself run the sweeps.
- `constellations.mjs`, `constellations.json`, `constellations.log`:330 node rows.
- `targeted.mjs`, `targeted.json`, `targeted.log`:slow, projectile binding, Mirror and replacement observations.
- `regression.log`:36 existing-test results.

If separately authorized to rerun, entry points are `node /tmp/ic-interactions/glyphs/audit.mjs`, `node /tmp/ic-interactions/glyphs/constellations.mjs`, and `node /tmp/ic-interactions/glyphs/targeted.mjs`; these overwrite the corresponding component result files. They were **not rerun for this synthesis**. The preserved terminal results show successful completion and no tool-denial evidence; no unavailable final worker narrative is treated as additional test evidence. Only this component Markdown report was authored during this synthesis.
