import fs from 'node:fs';import assert from 'node:assert/strict';import {game,target,frame,item,defs} from './fixtures.mjs';import {socketGlyph} from '/tmp/ic-audit-cloud/repo/src/glyphs.ts';
const rows=[];
for(const d of defs.secondary)for(const glyph of ['ignite','leech','tether'])for(const boss of [false,true]){
 const g=game({secondary:item('secondary',d)});g.save.glyphs[glyph]=1;assert.ok(socketGlyph(g.save,'tool',0,glyph).ok);g.player.hp=30;const e=target(g,13,10);e.boss=boss;const row={weapon:d[0],glyph,boss,damage:0,maxBurnUntil:0,maxSlowUntil:0,maxHp:30,maxHealPool:0,shots:0};
 frame(g,1000,['tool']);row.shots=g.projectiles.length;
 for(let i=1;i<=30;i++){frame(g,1000+i*50);row.maxBurnUntil=Math.max(row.maxBurnUntil,e.glyphBurn?.until||0);row.maxSlowUntil=Math.max(row.maxSlowUntil,e.glyphSlow?.until||0);row.maxHp=Math.max(row.maxHp,g.player.hp);row.maxHealPool=Math.max(row.maxHealPool,g.glyphHealPool||0)}row.damage=100000-e.hp;row.expectedEffect=glyph==='ignite'?row.maxBurnUntil>0:glyph==='tether'?row.maxSlowUntil>0:row.maxHp>30||row.maxHealPool>0;rows.push(row)
}
fs.writeFileSync('/tmp/ic-interactions/weapons/bombard-glyphs.json',JSON.stringify(rows,null,2));console.log(JSON.stringify(rows));
