import fs from 'node:fs';
import assert from 'node:assert/strict';
import {Game,characterStats,equipInventoryItem} from '/tmp/ic-audit-cloud/repo/src/game.ts';
import {freshSave,migrateSave} from '/tmp/ic-audit-cloud/repo/src/types.ts';
import {ITEM_TABLE,ITEM_TIERS,PRIMARY_PROFILES,RANGED_WEAPONS,upgradeEquipment,itemCap,generateItem,affixValue} from '/tmp/ic-audit-cloud/repo/src/items.ts';
import {normalizeSockets} from '/tmp/ic-audit-cloud/repo/src/glyphs.ts';
import {createCombatant} from '/tmp/ic-audit-cloud/repo/src/combat.ts';
import {masterwork,reforgeAffix,addSocket,salvageItem,SMITHY} from '/tmp/ic-audit-cloud/repo/src/smithy.ts';
const out='/tmp/ic-interactions/weapons',clone=x=>JSON.parse(JSON.stringify(x));
const defs={primary:[['Salvage Blade','steady','salvage-blade'],...ITEM_TABLE.primary.map(([n,p])=>[n,p,'primary-'+n.toLowerCase().replaceAll(' ','-')])],secondary:[['Spark Coil','focus','spark-coil'],...ITEM_TABLE.secondary.map(([n,p])=>[n,p,'secondary-'+n.toLowerCase().replaceAll(' ','-')])],armor:[['Ash Wrap','guard','ash-wrap'],...ITEM_TABLE.armor.map(([n,p])=>[n,p,'armor-'+n.toLowerCase().replaceAll(' ','-')])],charm:[...ITEM_TABLE.charm.map(([n,p])=>[n,p,'charm-'+n.toLowerCase().replaceAll(' ','-')]),['Echo Compass','reach','echo-compass']]};
function item(slot,def,tier='common'){return normalizeSockets({id:def[2],name:def[0],property:def[1],slot,tier,power:6,basePower:6,upgradeRank:0,affixes: def[0]==='Echo Compass'?[{id:'reach',value:.08},{id:'movement',value:.03}]:[]})}
function game(equip={},seed='WEAPONS-455'){const s=freshSave();s.seed=seed;Object.assign(s.equipment,clone(equip));const g=new Game(s,0);g.area='overworld';g.rx=3;g.ry=3;const W=32;g.map={width:W,height:W,entry:{x:10,y:10},objects:[],enemySpawns:[],tiles:Array.from({length:W*W},(_,i)=>({x:i%W,y:Math.floor(i/W),kind:'floor',blocked:false,elev:0}))};g.enemies=[];g.projectiles=[];g.effects=[];g.packEffects=[];g.storm=null;g.seaHazards=null;g.player.x=10;g.player.y=10;g.player.meleeAim={x:1,y:0};g.save.lastAim={x:1,y:0};g.player.facing='right';return g}
function target(g,x=11.1,y=10,kind='ashling'){const e=createCombatant(kind,x,y);e.id='audit-target';e.hp=e.maxHp=100000;e.cooldown=e.eliteCooldown=100000;e.speedMultiplier=0;e.dormant=true;g.enemies=[e];return e}
function frame(g,now,actions=[]){const set=new Set(actions);g.update(.05,{state:{x:0,y:0},consume:k=>set.delete(k),held:()=>false,reset(){}},now)}

export {game,target,frame,item,defs,clone};
