# Weapons equipment affixes and active skill interaction audit

Pinned release455 commit `04c11a0d3b73eeb9c767e9548cd3724c92a8dba9`. All custom harnesses/logs/results under `/tmp/ic-interactions/weapons`; repository `/tmp/ic-audit-cloud/repo` unchanged. Read AGENTS, AGENT_CONTEXT item/awakening/death boundaries, field-guide item profiles/high-risk invariants/extension recipes, current source and relevant tests. No production saves, source changes, commits, workflows or publication.

## Confirmed MAJOR interaction defect

### Rift Bombard loses tool on-hit glyph effects during grenade detonation

**Expected:** Validly socketed Ignite burns on a tool hit, Tether slows, Leech heals/accumulates healing. `src/glyphs.ts:19–28` player-facing tool contracts apply to secondary tools without a Bombard exception.

**Actual:** All6 Rift Bombard cases (3 glyphs × ordinary/boss-flag target) deal20 damage but produce zero burn timer, zero slow timer, and zero heal/fractional heal pool. The other18 cases using Spark Coil/Lumen Spindle/Needle Caster exercise the expected effects. The two boss flags are a static damage-target variation, not a full boss fight.

**Exact reproduction:** Run `node /tmp/ic-interactions/weapons/bombard-glyphs.mjs`. Fresh seed `WEAPONS-455`, equip valid common Rift Bombard (power6), grant one glyph then call production `socketGlyph(save,'tool',0,id)` with `ignite`, `leech` or `tether`. Synthetic open32×32 arena at section(3,3), player(10,10), target ashling(13,10), targetHP100000/cooldowns100000/speedMultiplier0 to prevent incidental deaths/movement. Set playerHP30/60; submit tool input at1000ms through `Game.update(.05,...)`, then30more50ms updates. Both normal and boss flag fail. `bombard-glyphs.json` records full observations and controls; seed/fixture is shared in `fixtures.mjs`.

**Source:** `src/game.ts:4739` turns the grenade into a `rift-blast` effect without copying `glyphHost` (or equivalent on-hit provenance). `:4755–4767` dispatches effect `glyphDamage`/`glyphHit` only when the effect has that host. Normal projectile callbacks `:4748–4749` therefore never run the on-hit glyph behavior for the grenade damage. Direct shot stat modifiers are separately applied before detonation; do not claim every glyph modifier fails.

**Suggested fix area, not implemented:** Preserve appropriate tool on-hit provenance when converting a projectile to a blast, define once-per-target semantics and prevent secondary/echo recursion, then regress all10tool glyphs/resonances on Bombard and reflected/shadow variants. This audit directly confirms only Ignite/Leech/Tether failures; other consequences remain hypotheses.

**Important control:** Spark Coil's12damage Leech hit gives0.96healing in `glyphHealPool`, so its first hit shows no whole HP increase. This is intended accumulation at `game.ts:2482`; it is **not** another no-op finding. Lumen/Needle give visible1HP and residual fractions. Bombard has no fractional pool at all despite20damage.

## Catalog and mechanical contracts

12named equipment identities mapped; identity coverage is not every procedural random instance:

- Primary3: Salvage Blade (cone1.7/100degrees/base7), Cinder Pike (thrust2.45/32/base8), Verge Cleaver (arc1.75/180/base9).
- Secondary4: Spark Coil (magic,straight,base8,speed12,life1.6), Lumen Spindle (magic,boomerang,base11,speed10,life1.8/turn0.8), Needle Caster (physical,straight,base10,speed15,life1.25), Rift Bombard (magic,grenade,base16,speed8,life1.4,blast radius2.15).
- Armor3: Ash Wrap starter, Kiln Mantle, Glassweave Coat.
- Charms2: Quiet Compass, story Echo Compass (reach0.08/movement0.03).

Source `items.ts:3–6,32–44`; starters `types.ts:12`; story reward `story.ts:11`; level4/8milestone name-based fallbacks `game.ts:250–265`. Generated names resolve correct profiles despite randomized IDs. Four tiers common/rare/epic/relic cap3/4/5/6 upgrades; masterwork adds one. Primary/secondary use weapon spheres; armor/charm use armor spheres; upgrade cost new rank. Charms intentionally cannot take glyph sockets. Equipment `property` labels are not independently modeled bonus systems beyond current profile/derived-stat implementations; no unsupported expectation of a separate Glassweave stamina bonus was assumed.

Four affix mechanics, seven legal slot-affix placements: primary attack/reach, secondary attack/reach, armor ward, charm movement/reach (`items.ts:58`). `characterStats` (`game.ts:311–353`) applies attack to weapon-specific bonus, reach from primary/secondary/charm globally, movement from charm/armor where present, and armor/charm ward to mitigation capped0.45. Echo Compass is an actual story-only identity; no new loot claim.

Awakened primary releases one crescent every third accepted swing; awakened tool produces a three-shot fan with half-damage sides (`game.ts:4186–4193,4248–4252`). Shared primary/tool readiness gates420ms/360ms base, altered by glyphs/armor speed. Equipment/preset switches must not clear this timer. Stun consumes input before either attack. Nanobot Knight scatters plain physical hits; magic or Echo/elemental glyph equipment can hit (`game.ts:3908–3913`, `monster-pack.ts:659`).

## Executed coverage matrix

| Scope | Executed cases | Outcome and interpretation |
|---|---:|---|
| All slot identity combinations ×4tiers ×base/capped rank |576|3primary×4secondary×3armor×2charm×4×2. Actual melee input hit, immediate repeat rejected, actual tool projectile/effect impact; finite derived stats and normalized JSON migration gear persistence. Zero failures. Uniform tier/rank treatment across slots per case; not all mixed-tier/rank permutations. |
| Upgrade/masterwork/socket/equip swap |48|12identities×4tiers. Exact sphere deductions each rank, cap refusal, masterwork+1, extra socket once (charm correctly refused), reload and bidirectional inventory swaps conserve items. Zero failures. |
| Affix standalone and pairwise placements |28|7standalone+all21unordered pairs. Derived benefits, live melee/tool impacts, movement-distance benefit, real `packHurt` mitigation, equip removal of effect, persistence. Zero failures. Static chosen valid-affix magnitudes; not all random magnitudes. |
| Weapon boundaries |35|7profiles×5categories: untargetable target, wall, stun, equip/preset cooldown retention, awakened attacks.34expected outcomes; Bombard blast-wall behavior below is an observation with unresolved design intent, not a passed wall-block invariant. |
| Reforge |28|7slot-affix placements×4tiers,20reforges each=560paid requests. Exact40marks/3iron charges, no duplicated affix kinds, finite stats. Zero failures. |
| Generated loot resolution |1000items|Seeds `WEAPON-CATALOG-0`…999, levels1…20; observed all32loot-name×tier pairs (8loot identities×4tiers), proper randomized-ID profile resolution. Not1000combat cases. |
| Lumen Phial ×tool ×awakening |8|4tools×awakened false/true. Charge decremented once, empty stock refused, correct45s buff/save-resume/expiry. Magic×1.4rounded; physical Needle unchanged. Zero failures. |
| All7weapons ×all6active skills |42|Rank1 learned by production `learnApertureSkill`, Aperture200fixture. Successful activation, repeat cooldown refusal, real weapon impacts, shared weapon cooldown; Force boosts all7, Ember boosts3melee, other tested skills do not unexpectedly alter damage. Zero failures. |
| Tool on-hit glyph checks |24|4tools×Ignite/Leech/Tether×normal/boss flag.18expected,6Bombard missing effects, one shared root cause. |
| Equipment death/reload and weapon pause/resume |19|12identities preserve gear/marks/spheres after actual zero-HP death and Game reconstruction;7weapon profiles freeze projectiles during pause, shift readiness correctly, reconstruct remaining cooldown. Zero failures. |
| Nanobot resistance interaction |21|7weapons×plain/Ignite/Echo, actual production attack/update. Plain3melee+Needle scatter/no damage; magic and glyph-equipped variants damage. Zero failures. |
| Focused existing regression rerun |25tests|Equipment/ranged/upgrade/affix/preset/smith patterns in prototype,smithy395,build-presets393; all pass. Overlaps previously passed1424suite, not25additional unique tests. |

This comprises829custom scenario records plus1000generated-item samples;560reforge requests are nested in28scenarios, not additive cases. Exact suites are separate because their assertions differ; do not label829independent population samples or “all combinations.”

### Lumen Phial measured base shot values

At synthetic power6secondary and fresh character stats: Spark12→17, Spindle15→21, Needle14→14, Bombard20→28. Awakened fan impacts need not simply equal3×base because side trajectories and returning boomerang intersections differ; the test verifies configured fan count and actual aggregate hits without inventing a fixed damage multiplier. `phial.json` contains values.

### Active skill cross setup

Six actives: Ember Form, Quickening, Veil Guard, Force Channel, Aerial Step, Rift Step. After activation target is placed relative to resulting player position, so Rift Step is not falsely penalized for having moved the player. These42cases cover weapon effects and readiness, not traversal safety/all skill ranks/passive forms; those belong to the spell/core scopes. Actual skill cooldowns and damage deltas are in `skill-cross.json`.

## Measured caveat and scope limitations

Rift Bombard blast crosses a solid full-height wall in the tested fixture: wallcolumn12, player(10,10), target(13.2,10), open map elsewhere; blast damages20 while other profiles cause0. Grenade movement respects the wall but its radial effect lacks a line-of-sight rule. No explicit blast-LOS contract was established; therefore this is a **design question**, not a confirmed defect. Some melee wall controls are also beyond ordinary melee range and do not independently prove close-range wall blocking; all-angle hitbox geometry is not covered.

All combat here uses synthetic flat arenas and durable, slowed targets; this isolates mechanics, not natural progression/balance or an entire worldboss encounter. Gear uses valid named identities with synthetic power/tier variants, including starter/story identities not naturally dropped at every tier. Generated loot sampler separately verifies actual loot names/tiers. No natural human play, rendered UI, touchscreen latency, audio, environment/height combinations, full projectile hitbox matrix or performance benchmark.

No exhaustive crossing of all weapons×all10glyphs×all6spells×all6skills×armor glyphs×echoes×constellation/lattice×consumables×all bosses was attempted. This report covers equipment identity cartesian combinations, legal affix placement pairs, all weapons×rank1actives, and the named higher-risk interactions only. Unsupported/nonexistent “Fracture” glyph was not invented; the current registry has10actual glyphs. Astral Cloak is not treated as an equipment identity here; parent owns name resolution, not substituted Astral mounting. Removing equipped gear is not exposed as an ordinary player operation in the inspected swap helper; arbitrary null-slot mutation is not counted as a supported unequip workflow.

Delayed projectile/equip glyph binding remains a source lead: shots store a host rather than immutable glyph payload; changing gear before impact may change on-hit behavior. This subtask has not established its intended contract or reproduced it as a defect. No duplicate-item, infinite-resource or nonfinite-gameplay result arose in the tested valid-input cases. Inventory cap, malformed save fuzz, offline cache, and all death inventory edge states are not exhausted here.

## Fixture validation and reproducibility

Initial harness assertions were corrected before final results: migration legitimately adds normalized empty glyph sockets to synthetic equipment; charmed gear legitimately refuses sockets; fractional Leech heal accumulation is intentional. One initial wall target overlapped the wall and was moved to valid floor at13.2 before final wall observations. These were **harness errors**, not game defects. Final JSON/logs reflect corrected fixtures; source never changed.

Run sequentially with Node24.22.1 and pinned checkout in stated path:

```sh
node /tmp/ic-interactions/weapons/audit.mjs
node /tmp/ic-interactions/weapons/interactions.mjs
node /tmp/ic-interactions/weapons/phial.mjs
node /tmp/ic-interactions/weapons/skill-cross.mjs
node /tmp/ic-interactions/weapons/bombard-glyphs.mjs
node /tmp/ic-interactions/weapons/lifecycle.mjs
node /tmp/ic-interactions/weapons/nanobot.mjs
cd /tmp/ic-audit-cloud/repo
node --test --test-concurrency=1 --test-name-pattern='weapon|equipment|affix|Rift Bombard|upgrade|Awaken|ranged|primary attack|cooldown|preset|smith|salvage|socket|masterwork|reforge' tests/prototype.test.ts tests/smithy-395.test.ts tests/build-presets-393.test.ts
```

Corresponding JSON/log files accompany each script; audit→results.json/run.log, interactions→interactions.json/log, others matching stems. Shared synthetic setup is `fixtures.mjs`. Final `git status --porcelain=v1` empty. No blocked/denied shell execution in this subtask; no escalation or network/browser actions.
